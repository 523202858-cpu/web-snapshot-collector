# Version 1 intentionally keeps code unobfuscated for easier troubleshooting.
