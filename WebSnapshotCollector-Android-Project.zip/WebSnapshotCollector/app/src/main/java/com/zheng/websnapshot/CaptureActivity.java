package com.zheng.websnapshot;

import android.app.Activity;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.RectF;
import android.net.Uri;
import android.net.http.SslError;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.os.Process;
import android.provider.MediaStore;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.webkit.CookieManager;
import android.webkit.RenderProcessGoneDetail;
import android.webkit.SslErrorHandler;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * 每次只处理一个网址，并运行在独立的 :capture 进程中。
 * 主进程只负责清单与断点，因此网页渲染进程即使崩溃也不会把整批任务带走。
 */
public class CaptureActivity extends Activity {
    public static final String EXTRA_SOURCE_ID = "source_id";
    public static final String EXTRA_LABEL = "label";
    public static final String EXTRA_URL = "url";
    public static final String EXTRA_MODE = "mode";
    public static final String EXTRA_LOAD_IMAGES = "load_images";
    public static final String EXTRA_MANUAL_LABEL = "manual_label";
    public static final String EXTRA_NAME_RESOLVED = "name_resolved";
    public static final String EXTRA_SEQUENCE_NUMBER = "sequence_number";
    public static final String EXTRA_SEQUENCE_TOTAL = "sequence_total";
    public static final String EXTRA_SUCCESS = "success";
    public static final String EXTRA_REASON = "reason";
    public static final String EXTRA_DETECTED_NAME = "detected_name";
    public static final int RESULT_PAUSED = Activity.RESULT_FIRST_USER + 17;

    private static final String ALBUM_ROOT = "六合彩资料";
    private static final String WORKER_STATE_FILE = "capture_worker_state.json";
    private static final String MODE_SMART = "smart";
    private static final String MODE_FIXED_SHORT = "fixed_short";
    private static final String MODE_FAST_LONG = "fast_long";
    private static final String MODE_COMPAT_SHORT = "compat_short";
    private static final String MODE_COMPAT_LONG = "compat_long";
    private static final int OUTPUT_WIDTH = 1080;
    private static final int SHORT_BODY_HEIGHT = 4800;
    private static final int LONG_BODY_HEIGHT = 8000;
    private static final int HEADER_HEIGHT = 104;
    private static final long PAGE_TIMEOUT_MS = 18000L;
    private static final long OVERALL_TIMEOUT_MS = 65000L;
    private static final int MAX_INNER_SCROLL_STEPS = 45;
    private static int completedSinceProcessStart = 0;

    private final Handler handler = new Handler(Looper.getMainLooper());
    private final ExecutorService fileExecutor = Executors.newSingleThreadExecutor();
    private WebView webView;
    private TextView statusView;
    private TextView urlView;
    private ProgressBar progressView;
    private boolean finished;
    private boolean workflowStarted;
    private int generation;

    private String sourceId;
    private String label;
    private String url;
    private String mode;
    private boolean loadImages;
    private boolean manualLabel;
    private boolean nameResolved;
    private int sequenceNumber;
    private int sequenceTotal;
    private String detectedName = "";
    private RegionResult region = new RegionResult();

    private Bitmap outputBitmap;
    private Canvas outputCanvas;
    private CapturePlan capturePlan;
    private float documentScale;
    private float regionLeftPx;
    private float regionRightPx;
    private float targetTopPx;
    private float targetBottomPx;
    private float cursorYPx;
    private float cursorXPx;
    private float currentRowEndPx;
    private int desiredRowScrollY;
    private int tileCount;

    private final Runnable pageTimeout = () -> finishFailure("网页加载超时");
    private final Runnable overallTimeout = () -> finishFailure("单个网址处理超时");

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        readArguments();
        buildUi();
        if (!url.matches("(?i)^https?://.+")) {
            finishFailure("网址格式不正确");
            return;
        }
        writeStage("启动网页");
        configureWebView();
        handler.postDelayed(pageTimeout, PAGE_TIMEOUT_MS);
        handler.postDelayed(overallTimeout, OVERALL_TIMEOUT_MS);
        webView.loadUrl(url);
    }

    private void readArguments() {
        Intent intent = getIntent();
        sourceId = value(intent.getStringExtra(EXTRA_SOURCE_ID));
        label = value(intent.getStringExtra(EXTRA_LABEL));
        url = value(intent.getStringExtra(EXTRA_URL));
        mode = value(intent.getStringExtra(EXTRA_MODE));
        if (mode.isEmpty()) mode = MODE_SMART;
        loadImages = intent.getBooleanExtra(EXTRA_LOAD_IMAGES, false);
        manualLabel = intent.getBooleanExtra(EXTRA_MANUAL_LABEL, false);
        nameResolved = intent.getBooleanExtra(EXTRA_NAME_RESOLVED, false);
        sequenceNumber = Math.max(1, intent.getIntExtra(EXTRA_SEQUENCE_NUMBER, 1));
        sequenceTotal = Math.max(sequenceNumber, intent.getIntExtra(EXTRA_SEQUENCE_TOTAL, sequenceNumber));
    }

    private void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.WHITE);

        statusView = new TextView(this);
        statusView.setTextSize(16);
        statusView.setTextColor(Color.rgb(20, 70, 120));
        statusView.setPadding(dp(10), dp(8), dp(10), dp(2));
        setStatus("准备加载");
        root.addView(statusView, matchWrap());

        urlView = new TextView(this);
        urlView.setText(label + " · " + (loadImages ? "有图" : "无图") + "\n" + url);
        urlView.setTextSize(11);
        urlView.setTextColor(Color.DKGRAY);
        urlView.setMaxLines(2);
        urlView.setPadding(dp(10), 0, dp(10), dp(4));
        root.addView(urlView, matchWrap());

        LinearLayout controls = new LinearLayout(this);
        controls.setGravity(Gravity.CENTER_VERTICAL);
        progressView = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        progressView.setIndeterminate(true);
        controls.addView(progressView, new LinearLayout.LayoutParams(0, dp(40), 1));
        Button pause = new Button(this);
        pause.setText("暂停任务");
        pause.setTextSize(13);
        pause.setAllCaps(false);
        pause.setOnClickListener(v -> pauseTask());
        controls.addView(pause, new LinearLayout.LayoutParams(dp(96), dp(40)));
        root.addView(controls, matchWrap());

        webView = new WebView(this);
        root.addView(webView, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1));
        setContentView(root);
    }

    private void configureWebView() {
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setLoadsImagesAutomatically(loadImages);
        settings.setBlockNetworkImage(!loadImages);
        settings.setUseWideViewPort(true);
        settings.setLoadWithOverviewMode(true);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);
        settings.setSupportMultipleWindows(false);
        settings.setJavaScriptCanOpenWindowsAutomatically(false);
        settings.setMediaPlaybackRequiresUserGesture(true);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE);
        settings.setUserAgentString(settings.getUserAgentString() + " SnapshotReader/1.5");
        CookieManager.getInstance().setAcceptCookie(true);
        CookieManager.getInstance().setAcceptThirdPartyCookies(webView, true);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) settings.setSafeBrowsingEnabled(true);
        webView.setBackgroundColor(Color.WHITE);
        webView.setLayerType(View.LAYER_TYPE_SOFTWARE, null);
        webView.setRendererPriorityPolicy(WebView.RENDERER_PRIORITY_BOUND, true);
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageStarted(WebView view, String currentUrl, Bitmap favicon) {
                if (finished) return;
                setStatus("正在加载网页");
                writeStage("加载网页");
            }

            @Override
            public void onPageFinished(WebView view, String currentUrl) {
                if (finished || workflowStarted) return;
                workflowStarted = true;
                handler.removeCallbacks(pageTimeout);
                final int token = ++generation;
                setStatus("等待页面内容");
                long settle = isCompatibilityMode() ? 2200L : 1200L;
                handler.postDelayed(() -> preparePage(token), settle);
            }

            @Override
            public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
                if (request.isForMainFrame()) finishFailure("网络错误：" + error.getDescription());
            }

            @Override
            public void onReceivedHttpError(WebView view, WebResourceRequest request, WebResourceResponse response) {
                if (request.isForMainFrame() && response.getStatusCode() >= 400) {
                    finishFailure("HTTP " + response.getStatusCode());
                }
            }

            @Override
            public void onReceivedSslError(WebView view, SslErrorHandler sslHandler, SslError error) {
                sslHandler.cancel();
                finishFailure("HTTPS证书错误");
            }

            @Override
            public boolean onRenderProcessGone(WebView view, RenderProcessGoneDetail detail) {
                finishFailure(detail.didCrash() ? "网页渲染进程崩溃" : "网页占用内存过高，渲染进程被系统关闭");
                return true;
            }
        });
    }

    private void preparePage(int token) {
        if (!active(token)) return;
        writeStage(loadImages ? "识别网站名称" : "整理无图页面");
        if (loadImages) {
            detectPageName(token);
            return;
        }
        setStatus("正在整理无图页面");
        String script = "(function(){function clean(doc){try{if(!doc||!doc.documentElement)return;" +
                "var old=doc.getElementById('__snapshot_no_image__');if(!old){var s=doc.createElement('style');" +
                "s.id='__snapshot_no_image__';s.textContent='img,picture,video,source,input[type=image]{display:none!important;}*{background-image:none!important;}';" +
                "(doc.head||doc.documentElement).appendChild(s);}" +
                "var frames=doc.querySelectorAll('iframe,frame');for(var i=0;i<frames.length;i++){try{clean(frames[i].contentDocument);}catch(e){}}" +
                "}catch(e){}}clean(document);return true;})()";
        webView.evaluateJavascript(script, ignored -> {
            if (active(token)) detectPageName(token);
        });
    }

    private void detectPageName(int token) {
        if (!active(token)) return;
        if (manualLabel || nameResolved) {
            continueAfterName(token);
            return;
        }
        setStatus("正在识别网站名称");
        String script = "(function(){function clean(v){return (v||'').replace(/\\s+/g,' ').trim();}" +
                "function generic(v){return !v||/^(首页|主页|home|index|welcome|document|untitled)$/i.test(v);}" +
                "function pick(doc){try{var t=clean(doc.title);if(!generic(t))return t;" +
                "var list=doc.querySelectorAll('h1,h2,.logo,.site-title,.title');for(var i=0;i<list.length;i++){" +
                "var s=clean(list[i].innerText||list[i].textContent);if(s.length>=2&&s.length<=60&&!generic(s))return s;}}catch(e){}return '';}" +
                "var result=pick(document);if(result)return result;var frames=document.querySelectorAll('iframe,frame');" +
                "for(var i=0;i<frames.length;i++){try{var s=pick(frames[i].contentDocument);if(s)return s;}catch(e){}}return '';})()";
        webView.evaluateJavascript(script, value -> {
            if (!active(token)) return;
            detectedName = sanitizeDetectedName(decodeJavascriptString(value));
            if (!detectedName.isEmpty()) {
                label = detectedName;
                urlView.setText(label + " · " + (loadImages ? "有图" : "无图") + "\n" + url);
            }
            continueAfterName(token);
        });
    }

    private void continueAfterName(int token) {
        if (isCompatibilityMode()) {
            scrollInnerContent(token, 0, 0);
        } else {
            analyzeAndExpand(token);
        }
    }

    private void scrollInnerContent(int token, int step, int stablePasses) {
        if (!active(token)) return;
        setStatus("正在读取页面内部内容");
        writeStage("读取内部滚动区");
        String script = "(function(){var moved=0;function walk(doc){try{var all=doc.querySelectorAll('*');" +
                "for(var i=0;i<all.length;i++){var el=all[i];if(el===doc.body||el===doc.documentElement)continue;" +
                "var ch=el.clientHeight||0,sh=el.scrollHeight||0;if(ch>60&&sh>ch+16){var before=el.scrollTop||0;" +
                "var next=Math.min(sh-ch,before+Math.max(80,Math.floor(ch*.82)));el.scrollTop=next;if((el.scrollTop||0)>before+1)moved++;}}" +
                "var frames=doc.querySelectorAll('iframe,frame');for(var j=0;j<frames.length;j++){try{walk(frames[j].contentDocument);}catch(e){}}" +
                "}catch(e){}}walk(document);return moved;})()";
        webView.evaluateJavascript(script, value -> {
            if (!active(token)) return;
            int moved = parseJavascriptInt(value);
            if (moved > 0 && step < MAX_INNER_SCROLL_STEPS) {
                handler.postDelayed(() -> scrollInnerContent(token, step + 1, 0), 150L);
            } else if (stablePasses == 0 && step < MAX_INNER_SCROLL_STEPS) {
                handler.postDelayed(() -> scrollInnerContent(token, step + 1, 1), 650L);
            } else {
                analyzeAndExpand(token);
            }
        });
    }

    private void analyzeAndExpand(int token) {
        if (!active(token)) return;
        setStatus("正在识别有效资料区");
        writeStage("识别有效资料区");
        String script = buildRegionScript(expectedIssueNumber());
        webView.evaluateJavascript(script, value -> {
            if (!active(token)) return;
            region = RegionResult.fromJavascript(value);
            setStatus(region.validIssueRegion
                    ? "已识别 " + region.distinctIssues + " 个不同期号，准备截图"
                    : "未可靠识别资料区，使用保底截图");
            webView.scrollTo(0, 0);
            handler.postDelayed(() -> startViewportCapture(token), 650L);
        });
    }

    private String buildRegionScript(int expectedIssue) {
        return ("(function(){var expected=__EXPECTED__;" + """
                var documents=[],candidates=[],markers=[];
                function force(el,key,value){try{el.style.setProperty(key,value,'important');}catch(e){}}
                function pushCandidate(el,kind,contentHeight){
                  if(!el)return;
                  for(var i=0;i<candidates.length;i++)if(candidates[i].el===el){
                    candidates[i].contentHeight=Math.max(candidates[i].contentHeight||0,contentHeight||0);
                    if(kind==='scroll'||kind==='frame')candidates[i].kind=kind;
                    return;
                  }
                  candidates.push({el:el,kind:kind,contentHeight:contentHeight||0});
                }
                function neutralizeFixed(doc){try{
                  var all=doc.querySelectorAll('*');
                  for(var i=0;i<all.length;i++){var el=all[i],s=doc.defaultView.getComputedStyle(el);
                    if(s.position==='fixed'||s.position==='sticky')force(el,'position','absolute');
                  }
                }catch(e){}}
                function walk(doc){try{
                  if(!doc||!doc.documentElement)return;documents.push(doc);neutralizeFixed(doc);
                  var frames=doc.querySelectorAll('iframe,frame');
                  for(var j=0;j<frames.length;j++){var fr=frames[j];try{
                    var child=fr.contentDocument;if(!child)continue;walk(child);
                    var de=child.documentElement,b=child.body;
                    var h=Math.max(de?de.scrollHeight:0,b?b.scrollHeight:0,de?de.offsetHeight:0,b?b.offsetHeight:0);
                    pushCandidate(fr,'frame',h);
                    if(h>0){force(fr,'max-height','none');force(fr,'height',h+'px');force(fr,'overflow','visible');}
                  }catch(e){}}
                  var all=doc.querySelectorAll('*');
                  for(var i=all.length-1;i>=0;i--){var el=all[i];if(el===doc.body||el===doc.documentElement)continue;
                    var ch=el.clientHeight||0,sh=el.scrollHeight||0,cw=el.clientWidth||0;
                    if(ch>60&&sh>ch+16&&cw>120){pushCandidate(el,'scroll',sh);force(el,'max-height','none');
                      force(el,'height',sh+'px');force(el,'overflow-y','visible');el.scrollTop=0;}
                  }
                }catch(e){}}
                function rootBoxFrom(doc,r){
                  var win=doc.defaultView,left=r.left+(win.pageXOffset||0),top=r.top+(win.pageYOffset||0);
                  var width=r.width||Math.max(0,r.right-r.left),height=r.height||Math.max(0,r.bottom-r.top);
                  try{while(win&&win.frameElement){var fr=win.frameElement,pdoc=fr.ownerDocument,pwin=pdoc.defaultView,br=fr.getBoundingClientRect();
                    left+=br.left+(pwin.pageXOffset||0);top+=br.top+(pwin.pageYOffset||0);win=pwin;}}catch(e){}
                  return {left:left,top:top,width:width,height:height,right:left+width,bottom:top+height};
                }
                function rootBox(el,contentHeight){try{
                  var r=el.getBoundingClientRect(),b=rootBoxFrom(el.ownerDocument,r);
                  var h=Math.max(b.height,contentHeight||0,el.scrollHeight||0),w=Math.max(b.width,el.scrollWidth||0);
                  b.width=w;b.height=h;b.right=b.left+w;b.bottom=b.top+h;return b;
                }catch(e){return null;}}
                function visible(el){try{var s=el.ownerDocument.defaultView.getComputedStyle(el);return s.display!=='none'&&s.visibility!=='hidden'&&s.opacity!=='0';}catch(e){return true;}}
                function addMarker(n,doc,r,el){
                  if(n<1||n>366||!r||!el||!visible(el))return;var b=rootBoxFrom(doc,r);
                  if(b.width<1&&b.height<1)return;markers.push({n:n,y:b.top+b.height/2,h:Math.max(1,b.height),el:el});
                }
                function scan(doc){try{
                  var root=doc.body||doc.documentElement;if(!root)return;
                  var walker=doc.createTreeWalker(root,4,null),node,count=0,re=/(?:第\\s*)?(\\d{1,3})\\s*期/g;
                  while((node=walker.nextNode())&&count<35000&&markers.length<1000){count++;
                    var parent=node.parentElement;if(!parent||/^(SCRIPT|STYLE|NOSCRIPT|TEXTAREA)$/i.test(parent.tagName))continue;
                    var value=node.nodeValue||'',match;re.lastIndex=0;
                    while((match=re.exec(value))!==null){try{var range=doc.createRange();range.setStart(node,match.index);range.setEnd(node,re.lastIndex);
                      addMarker(parseInt(match[1],10),doc,range.getBoundingClientRect(),parent);}catch(e){}if(match[0].length===0)re.lastIndex++;}
                  }
                  var tagged=doc.querySelectorAll('[alt],[title]');
                  for(var i=0;i<tagged.length&&markers.length<1000;i++){var text=(tagged[i].getAttribute('alt')||'')+' '+(tagged[i].getAttribute('title')||''),m;re.lastIndex=0;
                    while((m=re.exec(text))!==null){addMarker(parseInt(m[1],10),doc,tagged[i].getBoundingClientRect(),tagged[i]);if(m[0].length===0)re.lastIndex++;}}
                }catch(e){}}
                function addSemantic(doc){try{
                  var list=doc.querySelectorAll('main,article,[role=main],#content,#main,#container,.content,.main,.container,.list,.data,.info,.article,.detail,table,tbody,ul,ol');
                  for(var i=0;i<list.length;i++)pushCandidate(list[i],'semantic',0);
                  pushCandidate(doc.body||doc.documentElement,'root',0);
                }catch(e){}}
                function inside(m,b){return m.y>=b.top-2&&m.y<=b.bottom+2;}
                function stepDirection(before,after){
                  if(before===after)return 0;var diff=after-before;
                  if((diff>0&&diff<=45)||(before>=340&&after<=20))return 1;
                  if((diff<0&&diff>=-45)||(before<=20&&after>=340))return -1;
                  return 9;
                }
                function issueDistance(n){var d=Math.abs(n-expected);if(expected<=20&&n>=340)d=expected+(366-n);return d;}
                function analyze(box){
                  var raw=[],list=[],seen={},unique=0;
                  for(var i=0;i<markers.length;i++)if(inside(markers[i],box))raw.push(markers[i]);
                  raw.sort(function(a,b){return a.y-b.y;});
                  for(var r=0;r<raw.length;r++){var previous=list.length?list[list.length-1]:null;
                    if(previous&&previous.n===raw[r].n&&Math.abs(previous.y-raw[r].y)<8)continue;
                    list.push(raw[r]);if(!seen[raw[r].n]){seen[raw[r].n]=true;unique++;}}
                  var inc=0,dec=0,changes=0,invalid=0;
                  for(var j=1;j<list.length;j++){if(list[j-1].n===list[j].n)continue;changes++;
                    var dir=stepDirection(list[j-1].n,list[j].n);if(dir===1)inc++;else if(dir===-1)dec++;else invalid++;}
                  var dominant=Math.max(inc,dec),ratio=dominant/Math.max(1,changes),direction=inc>dec?1:(dec>inc?-1:0);
                  var valid=unique>=5&&dominant>=4&&ratio>=.65&&direction!==0;
                  var endpoint=null;if(valid)endpoint=direction>0?list[list.length-1]:list[0];
                  return {list:list,unique:unique,inc:inc,dec:dec,changes:changes,invalid:invalid,ratio:ratio,direction:direction,valid:valid,endpoint:endpoint};
                }
                walk(document);
                for(var d=0;d<documents.length;d++){addSemantic(documents[d]);scan(documents[d]);}
                var markerStep=Math.max(1,Math.floor(markers.length/90));
                for(var mi=0;mi<markers.length;mi+=markerStep){var ancestor=markers[mi].el;
                  for(var level=0;ancestor&&level<9;level++,ancestor=ancestor.parentElement)pushCandidate(ancestor,'ancestor',0);}
                var chosen=null,chosenBox=null,chosenAnalysis=null,chosenScore=-1e30;
                for(var c=0;c<candidates.length;c++){
                  var candidate=candidates[c],box=rootBox(candidate.el,candidate.contentHeight);
                  if(!box||box.width<120||box.height<160)continue;var a=analyze(box);if(!a.valid)continue;
                  var kindBonus=candidate.kind==='scroll'?2200:(candidate.kind==='frame'?2000:(candidate.kind==='semantic'?1200:700));
                  var endpointDistance=a.endpoint?issueDistance(a.endpoint.n):999;
                  var density=Math.min(2400,(a.unique*120000)/Math.max(240,box.height));
                  var score=kindBonus+a.unique*520+Math.max(a.inc,a.dec)*310+a.ratio*3500+density-Math.min(2200,box.height/7)-Math.min(1200,endpointDistance*25);
                  if(score>chosenScore){chosenScore=score;chosen=candidate;chosenBox=box;chosenAnalysis=a;}
                }
                var de=document.documentElement,b=document.body;
                var docWidth=Math.max(de?de.scrollWidth:0,b?b.scrollWidth:0,de?de.clientWidth:0);
                var docHeight=Math.max(de?de.scrollHeight:0,b?b.scrollHeight:0,de?de.clientHeight:0);
                var valid=!!(chosenBox&&chosenAnalysis&&chosenAnalysis.valid);
                if(!chosenBox){chosenBox={left:0,top:0,width:docWidth,height:docHeight,right:docWidth,bottom:docHeight};chosenAnalysis=analyze(chosenBox);}
                var latest=valid?chosenAnalysis.endpoint:null,atBottom=valid&&chosenAnalysis.direction>0;
                var issueTop=latest?latest.y-latest.h/2:0,issueHeight=latest?latest.h:0;
                var margin=6,left=Math.max(0,chosenBox.left-margin),top=Math.max(0,chosenBox.top-margin);
                var width=Math.max(1,Math.min(docWidth-left,chosenBox.width+margin*2));
                var height=Math.max(1,Math.min(docHeight-top,chosenBox.height+margin*2));
                try{document.documentElement.scrollTop=0;if(document.body)document.body.scrollTop=0;}catch(e){}
                return JSON.stringify({regionFound:width>120&&height>160,validIssueRegion:valid,left:left,top:top,width:width,height:height,
                  latestFound:!!latest,issue:latest?latest.n:0,issueTop:issueTop,issueHeight:issueHeight,atBottom:atBottom,
                  direction:chosenAnalysis?chosenAnalysis.direction:0,distinctIssues:chosenAnalysis?chosenAnalysis.unique:0,docWidth:docWidth,docHeight:docHeight});
                })()""").replace("__EXPECTED__", String.valueOf(expectedIssue));
    }

    private void startViewportCapture(int token) {
        if (!active(token)) return;
        writeStage("分屏拼接截图");
        setStatus("正在分屏拼接长图");
        int viewWidth = webView.getWidth();
        int viewHeight = webView.getHeight();
        if (viewWidth < 32 || viewHeight < 32) {
            finishFailure("网页显示区域为空");
            return;
        }
        documentScale = Math.max(0.05f, webView.getScale());
        float documentWidthCss = Math.max(region.documentWidth, webView.getWidth() / documentScale);
        float documentHeightCss = Math.max(region.documentHeight, webView.getContentHeight());
        if (!region.regionFound || region.width < 16f || region.height < 32f) {
            region.left = 0f;
            region.top = 0f;
            region.width = documentWidthCss;
            region.height = documentHeightCss;
            region.validIssueRegion = false;
            region.latestFound = false;
        }
        region.left = clamp(region.left, 0f, Math.max(0f, documentWidthCss - 1f));
        region.top = clamp(region.top, 0f, Math.max(0f, documentHeightCss - 1f));
        region.width = clamp(region.width, 1f, Math.max(1f, documentWidthCss - region.left));
        region.height = clamp(region.height, 1f, Math.max(1f, documentHeightCss - region.top));
        capturePlan = CapturePlan.create(region, mode);
        try {
            outputBitmap = Bitmap.createBitmap(OUTPUT_WIDTH, HEADER_HEIGHT + capturePlan.bodyHeight, Bitmap.Config.RGB_565);
            outputCanvas = new Canvas(outputBitmap);
            outputCanvas.drawColor(Color.WHITE);
            drawHeader(outputCanvas);
        } catch (OutOfMemoryError error) {
            recycleOutput();
            finishFailure("生成长图时内存不足");
            return;
        }
        regionLeftPx = region.left * documentScale;
        regionRightPx = (region.left + region.width) * documentScale;
        targetTopPx = capturePlan.cropTopCss * documentScale;
        targetBottomPx = (capturePlan.cropTopCss + capturePlan.cropHeightCss) * documentScale;
        cursorYPx = targetTopPx;
        cursorXPx = regionLeftPx;
        tileCount = 0;
        captureNextRow(token);
    }

    private void captureNextRow(int token) {
        if (!active(token)) return;
        if (cursorYPx >= targetBottomPx - 0.5f) {
            saveOutput(token);
            return;
        }
        int contentHeightPx = Math.max(webView.getHeight(), Math.round(webView.getContentHeight() * webView.getScale()));
        int maxScrollY = Math.max(0, contentHeightPx - webView.getHeight());
        desiredRowScrollY = Math.min(maxScrollY, Math.max(0, Math.round(cursorYPx)));
        cursorXPx = regionLeftPx;
        currentRowEndPx = -1f;
        captureNextTile(token);
    }

    private void captureNextTile(int token) {
        if (!active(token)) return;
        int contentWidthPx = Math.max(webView.getWidth(), Math.round(Math.max(region.documentWidth, region.left + region.width) * webView.getScale()));
        int maxScrollX = Math.max(0, contentWidthPx - webView.getWidth());
        int desiredX = Math.min(maxScrollX, Math.max(0, Math.round(cursorXPx)));
        webView.scrollTo(desiredX, desiredRowScrollY);
        handler.postDelayed(() -> drawCurrentTile(token), 180L);
    }

    private void drawCurrentTile(int token) {
        if (!active(token)) return;
        Bitmap tile = null;
        try {
            int viewWidth = webView.getWidth();
            int viewHeight = webView.getHeight();
            int actualX = webView.getScrollX();
            int actualY = webView.getScrollY();
            float visibleTop = Math.max(cursorYPx, actualY);
            float visibleBottom = Math.min(targetBottomPx, actualY + viewHeight);
            if (visibleBottom <= visibleTop + 0.5f) throw new IllegalStateException("页面无法滚动到目标资料区");
            if (currentRowEndPx < 0f) currentRowEndPx = visibleBottom;
            else visibleBottom = Math.min(visibleBottom, currentRowEndPx);

            float visibleLeft = Math.max(cursorXPx, actualX);
            float visibleRight = Math.min(regionRightPx, actualX + viewWidth);
            if (visibleRight <= visibleLeft + 0.5f) throw new IllegalStateException("页面无法横向滚动到目标资料区");

            tile = Bitmap.createBitmap(viewWidth, viewHeight, Bitmap.Config.RGB_565);
            Canvas tileCanvas = new Canvas(tile);
            tileCanvas.drawColor(Color.WHITE);
            webView.draw(tileCanvas);

            Rect source = new Rect(
                    clampInt(Math.round(visibleLeft - actualX), 0, viewWidth - 1),
                    clampInt(Math.round(visibleTop - actualY), 0, viewHeight - 1),
                    clampInt(Math.round(visibleRight - actualX), 1, viewWidth),
                    clampInt(Math.round(visibleBottom - actualY), 1, viewHeight));
            if (source.right <= source.left || source.bottom <= source.top) throw new IllegalStateException("截图分片为空");

            RectF destination = new RectF(
                    (visibleLeft - regionLeftPx) / Math.max(1f, regionRightPx - regionLeftPx) * OUTPUT_WIDTH,
                    HEADER_HEIGHT + (visibleTop - targetTopPx) / Math.max(1f, targetBottomPx - targetTopPx) * capturePlan.bodyHeight,
                    (visibleRight - regionLeftPx) / Math.max(1f, regionRightPx - regionLeftPx) * OUTPUT_WIDTH,
                    HEADER_HEIGHT + (visibleBottom - targetTopPx) / Math.max(1f, targetBottomPx - targetTopPx) * capturePlan.bodyHeight);
            Paint paint = new Paint(Paint.FILTER_BITMAP_FLAG | Paint.DITHER_FLAG);
            outputCanvas.drawBitmap(tile, source, destination, paint);
            tileCount++;
            int percent = Math.min(99, Math.max(1, Math.round((visibleBottom - targetTopPx) / Math.max(1f, targetBottomPx - targetTopPx) * 100f)));
            setStatus("正在拼接长图 " + percent + "%");

            cursorXPx = visibleRight;
            if (cursorXPx < regionRightPx - 0.5f) {
                handler.post(() -> captureNextTile(token));
            } else {
                float previousY = cursorYPx;
                cursorYPx = currentRowEndPx;
                if (cursorYPx <= previousY + 0.5f) throw new IllegalStateException("页面滚动没有前进");
                handler.post(() -> captureNextRow(token));
            }
        } catch (OutOfMemoryError error) {
            recycleOutput();
            finishFailure("分屏拼接时内存不足");
        } catch (Throwable error) {
            recycleOutput();
            finishFailure(error.getMessage() == null ? "分屏截图失败" : error.getMessage());
        } finally {
            if (tile != null && !tile.isRecycled()) tile.recycle();
        }
    }

    private void saveOutput(int token) {
        if (!active(token) || outputBitmap == null) return;
        setStatus("正在保存到独立相册");
        writeStage("保存长图");
        final Bitmap bitmapToSave = outputBitmap;
        outputBitmap = null;
        outputCanvas = null;
        final String filename = String.format(Locale.CHINA, "%03d_%s.jpg", sequenceNumber, safeName(label));
        fileExecutor.execute(() -> {
            String error = null;
            try {
                saveBitmap(bitmapToSave, filename);
            } catch (OutOfMemoryError memoryError) {
                error = "保存图片时内存不足";
            } catch (Throwable throwable) {
                error = throwable.getMessage() == null ? "保存图片失败" : throwable.getMessage();
            } finally {
                if (!bitmapToSave.isRecycled()) bitmapToSave.recycle();
            }
            final String finalError = error;
            handler.post(() -> {
                if (!active(token)) return;
                if (finalError == null) finishSuccess();
                else finishFailure(finalError);
            });
        });
    }

    private void drawHeader(Canvas canvas) {
        Paint background = new Paint(Paint.ANTI_ALIAS_FLAG);
        background.setColor(Color.rgb(236, 245, 253));
        canvas.drawRect(0, 0, OUTPUT_WIDTH, HEADER_HEIGHT, background);
        Paint strong = new Paint(Paint.ANTI_ALIAS_FLAG);
        strong.setColor(Color.rgb(16, 72, 125));
        strong.setTextSize(31);
        strong.setFakeBoldText(true);
        Paint small = new Paint(Paint.ANTI_ALIAS_FLAG);
        small.setColor(Color.DKGRAY);
        small.setTextSize(23);
        String regionHint;
        if (region.validIssueRegion) {
            regionHint = "  资料区" + region.distinctIssues + "期·" + (region.latestAtBottom ? "下部" : "上部");
        } else {
            regionHint = "  未识别资料区·保底";
        }
        String title = sequenceNumber + "/" + sequenceTotal + "  " + label + regionHint;
        String timestamp = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.CHINA).format(new Date());
        canvas.drawText(ellipsize(title, strong, OUTPUT_WIDTH - 32), 16, 40, strong);
        canvas.drawText(ellipsize(timestamp + "  " + url, small, OUTPUT_WIDTH - 32), 16, 79, small);
        Paint line = new Paint();
        line.setColor(Color.rgb(144, 202, 249));
        line.setStrokeWidth(2);
        canvas.drawLine(0, HEADER_HEIGHT - 2, OUTPUT_WIDTH, HEADER_HEIGHT - 2, line);
    }

    private void saveBitmap(Bitmap bitmap, String filename) throws Exception {
        String day = new SimpleDateFormat("yyyy-MM-dd", Locale.CHINA).format(new Date());
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            ContentResolver resolver = getContentResolver();
            ContentValues values = new ContentValues();
            values.put(MediaStore.Images.Media.DISPLAY_NAME, filename);
            values.put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg");
            values.put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/" + ALBUM_ROOT + "/" + day);
            values.put(MediaStore.Images.Media.IS_PENDING, 1);
            Uri uri = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values);
            if (uri == null) throw new Exception("无法创建相册图片");
            try (OutputStream output = resolver.openOutputStream(uri)) {
                if (output == null || !bitmap.compress(Bitmap.CompressFormat.JPEG, 82, output)) throw new Exception("图片压缩失败");
            } catch (Exception error) {
                resolver.delete(uri, null, null);
                throw error;
            }
            values.clear();
            values.put(MediaStore.Images.Media.IS_PENDING, 0);
            resolver.update(uri, values, null, null);
        } else {
            File directory = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES), ALBUM_ROOT + "/" + day);
            if (!directory.exists() && !directory.mkdirs()) throw new Exception("无法创建相册文件夹");
            File file = new File(directory, filename);
            try (OutputStream output = new FileOutputStream(file)) {
                if (!bitmap.compress(Bitmap.CompressFormat.JPEG, 82, output)) throw new Exception("图片压缩失败");
            }
            sendBroadcast(new Intent(Intent.ACTION_MEDIA_SCANNER_SCAN_FILE, Uri.fromFile(file)));
        }
    }

    private void finishSuccess() {
        finishWithResult(Activity.RESULT_OK, true, "");
    }

    private void finishFailure(String reason) {
        if (finished) return;
        finishWithResult(Activity.RESULT_CANCELED, false, reason == null || reason.trim().isEmpty() ? "截图失败" : reason.trim());
    }

    private void finishWithResult(int resultCode, boolean success, String reason) {
        if (finished) return;
        finished = true;
        generation++;
        handler.removeCallbacks(pageTimeout);
        handler.removeCallbacks(overallTimeout);
        recycleOutput();
        Intent data = new Intent();
        data.putExtra(EXTRA_SUCCESS, success);
        data.putExtra(EXTRA_REASON, reason);
        data.putExtra(EXTRA_DETECTED_NAME, detectedName);
        setResult(resultCode, data);
        destroyWebView();
        clearStageFile(this);
        completedSinceProcessStart++;
        boolean recycleProcess = completedSinceProcessStart >= 5;
        if (recycleProcess) completedSinceProcessStart = 0;
        finish();
        if (recycleProcess) {
            new Handler(Looper.getMainLooper()).postDelayed(() -> Process.killProcess(Process.myPid()), 350L);
        }
    }

    private void pauseTask() {
        if (finished) return;
        finished = true;
        generation++;
        handler.removeCallbacksAndMessages(null);
        recycleOutput();
        Intent data = new Intent();
        data.putExtra(EXTRA_DETECTED_NAME, detectedName);
        setResult(RESULT_PAUSED, data);
        destroyWebView();
        clearStageFile(this);
        finish();
    }

    @Override
    public void onBackPressed() {
        pauseTask();
    }

    @Override
    protected void onDestroy() {
        if (finished) clearStageFile(this);
        handler.removeCallbacksAndMessages(null);
        recycleOutput();
        destroyWebView();
        fileExecutor.shutdownNow();
        super.onDestroy();
    }

    private void destroyWebView() {
        if (webView == null) return;
        try {
            webView.stopLoading();
            webView.loadUrl("about:blank");
            webView.clearHistory();
            webView.clearFormData();
            webView.removeAllViews();
            webView.destroy();
        } catch (Throwable ignored) {
        }
        webView = null;
    }

    private void recycleOutput() {
        outputCanvas = null;
        if (outputBitmap != null && !outputBitmap.isRecycled()) outputBitmap.recycle();
        outputBitmap = null;
    }

    private boolean active(int token) {
        return !finished && token == generation && webView != null;
    }

    private boolean isCompatibilityMode() {
        return MODE_COMPAT_SHORT.equals(mode) || MODE_COMPAT_LONG.equals(mode);
    }

    private int expectedIssueNumber() {
        Calendar calendar = Calendar.getInstance(TimeZone.getTimeZone("Asia/Shanghai"), Locale.CHINA);
        return calendar.get(Calendar.DAY_OF_YEAR);
    }

    private void setStatus(String message) {
        if (statusView != null) statusView.setText("[" + sequenceNumber + "/" + sequenceTotal + "] " + message);
    }

    private void writeStage(String stage) {
        try {
            JSONObject state = new JSONObject();
            state.put("sourceId", sourceId);
            state.put("sequenceNumber", sequenceNumber);
            state.put("stage", stage);
            state.put("time", System.currentTimeMillis());
            try (FileOutputStream output = new FileOutputStream(new File(getFilesDir(), WORKER_STATE_FILE), false)) {
                output.write(state.toString().getBytes(StandardCharsets.UTF_8));
                output.flush();
            }
        } catch (Throwable ignored) {
        }
    }

    public static String readLastStageSuffix(Context context) {
        File file = new File(context.getFilesDir(), WORKER_STATE_FILE);
        if (!file.exists()) return "";
        try (FileInputStream input = new FileInputStream(file)) {
            byte[] bytes = new byte[(int) Math.min(file.length(), 4096L)];
            int count = input.read(bytes);
            if (count <= 0) return "";
            JSONObject state = new JSONObject(new String(bytes, 0, count, StandardCharsets.UTF_8));
            if (System.currentTimeMillis() - state.optLong("time", 0L) > 30 * 60 * 1000L) return "";
            String stage = state.optString("stage", "").trim();
            return stage.isEmpty() ? "" : "（阶段：" + stage + "）";
        } catch (Throwable ignored) {
            return "";
        }
    }

    private static void clearStageFile(Context context) {
        try {
            File file = new File(context.getFilesDir(), WORKER_STATE_FILE);
            if (file.exists()) file.delete();
        } catch (Throwable ignored) {
        }
    }

    private String decodeJavascriptString(String value) {
        if (value == null || "null".equals(value)) return "";
        try {
            return new JSONArray("[" + value + "]").getString(0);
        } catch (JSONException ignored) {
            return value.replace("\"", "").trim();
        }
    }

    private String sanitizeDetectedName(String detected) {
        String clean = detected == null ? "" : detected.replaceAll("\\s+", " ").trim();
        if (clean.length() > 40) clean = clean.substring(0, 40).trim();
        if (clean.length() < 2 || clean.matches("(?i)^(首页|主页|home|index|welcome|document|untitled)$") || clean.matches("(?i)^https?://.*")) return "";
        return clean;
    }

    private int parseJavascriptInt(String value) {
        try {
            return Integer.parseInt(value == null ? "0" : value.replace("\"", "").trim());
        } catch (NumberFormatException ignored) {
            return 0;
        }
    }

    private String safeName(String value) {
        String clean = value.replaceAll("[\\\\/:*?\"<>|\\s]+", "_");
        if (clean.length() > 36) clean = clean.substring(0, 36);
        return clean.isEmpty() ? "未命名来源" : clean;
    }

    private String ellipsize(String value, Paint paint, float width) {
        if (paint.measureText(value) <= width) return value;
        int end = value.length();
        while (end > 0 && paint.measureText(value.substring(0, end) + "…") > width) end--;
        return value.substring(0, Math.max(0, end)) + "…";
    }

    private String value(String text) {
        return text == null ? "" : text.trim();
    }

    private float clamp(float value, float minimum, float maximum) {
        return Math.max(minimum, Math.min(maximum, value));
    }

    private int clampInt(int value, int minimum, int maximum) {
        return Math.max(minimum, Math.min(maximum, value));
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    private LinearLayout.LayoutParams matchWrap() {
        return new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
    }

    private static class RegionResult {
        boolean regionFound;
        boolean validIssueRegion;
        boolean latestFound;
        boolean latestAtBottom;
        int latestIssue;
        int direction;
        int distinctIssues;
        float left;
        float top;
        float width;
        float height;
        float issueTop;
        float issueHeight;
        float documentWidth;
        float documentHeight;

        static RegionResult fromJavascript(String value) {
            RegionResult result = new RegionResult();
            try {
                String decoded = value;
                if (decoded == null || "null".equals(decoded)) return result;
                decoded = new JSONArray("[" + decoded + "]").getString(0);
                JSONObject object = new JSONObject(decoded);
                result.regionFound = object.optBoolean("regionFound", false);
                result.validIssueRegion = object.optBoolean("validIssueRegion", false);
                result.latestFound = object.optBoolean("latestFound", false);
                result.latestAtBottom = object.optBoolean("atBottom", false);
                result.latestIssue = object.optInt("issue", 0);
                result.direction = object.optInt("direction", 0);
                result.distinctIssues = object.optInt("distinctIssues", 0);
                result.left = (float) object.optDouble("left", 0d);
                result.top = (float) object.optDouble("top", 0d);
                result.width = (float) object.optDouble("width", 0d);
                result.height = (float) object.optDouble("height", 0d);
                result.issueTop = (float) object.optDouble("issueTop", 0d);
                result.issueHeight = (float) object.optDouble("issueHeight", 0d);
                result.documentWidth = (float) object.optDouble("docWidth", 0d);
                result.documentHeight = (float) object.optDouble("docHeight", 0d);
            } catch (Throwable ignored) {
                return new RegionResult();
            }
            return result;
        }
    }

    private static class CapturePlan {
        int bodyHeight;
        float cropTopCss;
        float cropHeightCss;

        static CapturePlan create(RegionResult region, String mode) {
            CapturePlan plan = new CapturePlan();
            float outputScale = OUTPUT_WIDTH / Math.max(1f, region.width);
            int naturalHeight = Math.max(1, Math.round(region.height * outputScale));
            boolean longMode = MODE_FAST_LONG.equals(mode) || MODE_COMPAT_LONG.equals(mode);
            if (MODE_SMART.equals(mode)) {
                if (naturalHeight <= SHORT_BODY_HEIGHT) {
                    plan.bodyHeight = naturalHeight;
                    plan.cropHeightCss = region.height;
                    plan.cropTopCss = region.top;
                } else if (region.validIssueRegion && region.latestFound) {
                    plan.bodyHeight = SHORT_BODY_HEIGHT;
                    plan.cropHeightCss = SHORT_BODY_HEIGHT / outputScale;
                    plan.cropTopCss = chooseCropTop(region, plan.cropHeightCss);
                } else if (naturalHeight <= LONG_BODY_HEIGHT) {
                    plan.bodyHeight = naturalHeight;
                    plan.cropHeightCss = region.height;
                    plan.cropTopCss = region.top;
                } else {
                    plan.bodyHeight = LONG_BODY_HEIGHT;
                    plan.cropHeightCss = region.height;
                    plan.cropTopCss = region.top;
                }
            } else {
                int requested = longMode ? LONG_BODY_HEIGHT : SHORT_BODY_HEIGHT;
                plan.bodyHeight = Math.min(requested, naturalHeight);
                if (naturalHeight <= requested) {
                    plan.cropHeightCss = region.height;
                    plan.cropTopCss = region.top;
                } else {
                    plan.cropHeightCss = requested / outputScale;
                    plan.cropTopCss = region.validIssueRegion && region.latestFound
                            ? chooseCropTop(region, plan.cropHeightCss)
                            : region.top;
                }
            }
            plan.cropHeightCss = Math.max(1f, Math.min(plan.cropHeightCss, region.height));
            plan.cropTopCss = Math.max(region.top, Math.min(plan.cropTopCss, region.top + region.height - plan.cropHeightCss));
            return plan;
        }

        private static float chooseCropTop(RegionResult region, float windowHeight) {
            float regionBottom = region.top + region.height;
            float issueCenter = region.issueTop + Math.max(1f, region.issueHeight) / 2f;
            float desired = region.latestAtBottom ? regionBottom - windowHeight : region.top;
            if (issueCenter < desired || issueCenter > desired + windowHeight) desired = issueCenter - windowHeight / 2f;
            return Math.max(region.top, Math.min(desired, regionBottom - windowHeight));
        }
    }
}
