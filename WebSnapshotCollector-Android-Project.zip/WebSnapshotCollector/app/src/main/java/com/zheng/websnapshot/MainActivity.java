package com.zheng.websnapshot;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.ContentResolver;
import android.content.ContentUris;
import android.content.ContentValues;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Picture;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.provider.MediaStore;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.webkit.CookieManager;
import android.webkit.SslErrorHandler;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import android.net.http.SslError;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.net.URI;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    private static final String PREFS = "sources_v1";
    private static final String KEY_SOURCES = "sources";
    private static final String ALBUM_ROOT = "六合彩资料";
    private static final int STORAGE_REQUEST = 81;
    private static final int OUTPUT_WIDTH = 1080;
    private static final int MAX_IMAGE_BODY_HEIGHT = 8000;
    private static final int HEADER_HEIGHT = 104;
    private static final long PAGE_SETTLE_MS = 2800;
    private static final long PAGE_TIMEOUT_MS = 35000;
    private static final int MAX_WARM_STEPS = 100;
    private static final int MAX_INNER_SCROLL_STEPS = 50;

    private final ArrayList<SourceItem> sources = new ArrayList<>();
    private final ArrayList<SourceItem> captureQueue = new ArrayList<>();
    private final ArrayList<SourceItem> failedQueue = new ArrayList<>();
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final ExecutorService imageExecutor = Executors.newSingleThreadExecutor();

    private FrameLayout root;
    private LinearLayout sourceScreen;
    private LinearLayout captureScreen;
    private SourceAdapter adapter;
    private TextView countText;
    private TextView captureStatus;
    private TextView captureUrl;
    private ProgressBar captureProgress;
    private Button retryButton;
    private WebView webView;

    private int captureIndex = -1;
    private int pageGeneration = 0;
    private boolean running = false;
    private boolean currentFailed = false;
    private String currentFailureReason = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        enableWholeDocumentDrawing();
        loadSources();
        buildUi();
        refreshSourceList();
    }

    @SuppressWarnings("deprecation")
    private void enableWholeDocumentDrawing() {
        WebView.enableSlowWholeDocumentDraw();
    }

    @Override
    protected void onDestroy() {
        running = false;
        pageGeneration++;
        handler.removeCallbacksAndMessages(null);
        if (webView != null) {
            webView.stopLoading();
            webView.destroy();
        }
        imageExecutor.shutdownNow();
        super.onDestroy();
    }

    @Override
    public void onBackPressed() {
        if (captureScreen.getVisibility() == View.VISIBLE) {
            confirmStop();
        } else {
            super.onBackPressed();
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == STORAGE_REQUEST) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                startAll();
            } else {
                toast("没有存储权限，无法把截图保存到公共相册");
            }
        }
    }

    private void buildUi() {
        root = new FrameLayout(this);
        sourceScreen = new LinearLayout(this);
        sourceScreen.setOrientation(LinearLayout.VERTICAL);
        sourceScreen.setPadding(dp(8), dp(8), dp(8), dp(8));

        TextView title = new TextView(this);
        title.setText("资料长图采集");
        title.setTextSize(22);
        title.setTextColor(Color.rgb(20, 70, 120));
        title.setGravity(Gravity.CENTER_VERTICAL);
        title.setPadding(dp(4), dp(5), dp(4), dp(6));
        sourceScreen.addView(title, matchWrap());

        countText = new TextView(this);
        countText.setTextSize(14);
        countText.setTextColor(Color.DKGRAY);
        countText.setPadding(dp(4), 0, dp(4), dp(5));
        sourceScreen.addView(countText, matchWrap());

        LinearLayout row1 = buttonRow();
        row1.addView(button("添加", v -> showAddDialog(false)), weightedButton());
        row1.addView(button("批量添加", v -> showAddDialog(true)), weightedButton());
        row1.addView(button("复制清单", v -> copySourceList()), weightedButton());
        sourceScreen.addView(row1, matchWrap());

        LinearLayout row2 = buttonRow();
        row2.addView(button("开始采集", v -> startAll()), weightedButton());
        retryButton = button("重试失败", v -> startFailed());
        row2.addView(retryButton, weightedButton());
        row2.addView(button("打开今日", v -> openTodayFirst()), weightedButton());
        row2.addView(button("删除今日", v -> confirmDeleteToday()), weightedButton());
        sourceScreen.addView(row2, matchWrap());

        TextView hint = new TextView(this);
        hint.setText("批量格式：每行一个网址，或“名称|网址”。取消勾选可暂时停用来源。");
        hint.setTextSize(12);
        hint.setTextColor(Color.GRAY);
        hint.setPadding(dp(4), dp(4), dp(4), dp(4));
        sourceScreen.addView(hint, matchWrap());

        ListView list = new ListView(this);
        list.setDividerHeight(dp(1));
        adapter = new SourceAdapter();
        list.setAdapter(adapter);
        sourceScreen.addView(list, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1));

        captureScreen = new LinearLayout(this);
        captureScreen.setOrientation(LinearLayout.VERTICAL);
        captureScreen.setVisibility(View.GONE);
        captureScreen.setBackgroundColor(Color.WHITE);

        captureStatus = new TextView(this);
        captureStatus.setTextSize(16);
        captureStatus.setTextColor(Color.rgb(20, 70, 120));
        captureStatus.setPadding(dp(10), dp(8), dp(10), dp(3));
        captureScreen.addView(captureStatus, matchWrap());

        captureUrl = new TextView(this);
        captureUrl.setTextSize(11);
        captureUrl.setTextColor(Color.DKGRAY);
        captureUrl.setMaxLines(2);
        captureUrl.setPadding(dp(10), 0, dp(10), dp(5));
        captureScreen.addView(captureUrl, matchWrap());

        LinearLayout progressRow = buttonRow();
        captureProgress = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        progressRow.addView(captureProgress, new LinearLayout.LayoutParams(0, dp(40), 1));
        progressRow.addView(button("停止", v -> confirmStop()), new LinearLayout.LayoutParams(dp(76), dp(40)));
        captureScreen.addView(progressRow, matchWrap());

        webView = new WebView(this);
        configureWebView();
        captureScreen.addView(webView, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1));

        root.addView(sourceScreen, frameMatch());
        root.addView(captureScreen, frameMatch());
        setContentView(root);
    }

    private void configureWebView() {
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setLoadsImagesAutomatically(true);
        settings.setBlockNetworkImage(false);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);
        settings.setSupportMultipleWindows(false);
        settings.setJavaScriptCanOpenWindowsAutomatically(false);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE);
        settings.setUserAgentString(settings.getUserAgentString() + " SnapshotReader/1.0");
        CookieManager.getInstance().setAcceptCookie(true);
        CookieManager.getInstance().setAcceptThirdPartyCookies(webView, true);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            settings.setSafeBrowsingEnabled(true);
        }
        webView.setBackgroundColor(Color.WHITE);
        webView.setLayerType(View.LAYER_TYPE_SOFTWARE, null);
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageStarted(WebView view, String url, Bitmap favicon) {
                currentFailed = false;
                currentFailureReason = "";
                captureStatus.setText(progressPrefix() + " 正在加载");
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                if (!running || currentFailed) return;
                final int token = ++pageGeneration;
                captureStatus.setText(progressPrefix() + " 等待页面内容");
                handler.postDelayed(() -> {
                    if (running && token == pageGeneration && !currentFailed) {
                        scrollInnerContent(token, 0, 0);
                    }
                }, PAGE_SETTLE_MS);
            }

            @Override
            public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
                if (request.isForMainFrame()) {
                    failCurrent("网络错误：" + error.getDescription());
                }
            }

            @Override
            public void onReceivedHttpError(WebView view, WebResourceRequest request, WebResourceResponse response) {
                if (request.isForMainFrame() && response.getStatusCode() >= 400) {
                    failCurrent("HTTP " + response.getStatusCode());
                }
            }

            @Override
            public void onReceivedSslError(WebView view, SslErrorHandler handler, SslError error) {
                handler.cancel();
                failCurrent("HTTPS证书错误");
            }
        });
    }

    private void showAddDialog(boolean batch) {
        EditText input = new EditText(this);
        input.setTextSize(15);
        input.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE | InputType.TYPE_TEXT_VARIATION_URI);
        input.setMinLines(batch ? 8 : 3);
        input.setGravity(Gravity.TOP | Gravity.START);
        input.setHint(batch ? "每行一个网址\n或：网站名称|https://example.com/page" : "网站名称|https://example.com/page");
        new AlertDialog.Builder(this)
                .setTitle(batch ? "批量添加网址" : "添加网址")
                .setView(input)
                .setPositiveButton("添加", (d, w) -> addLines(input.getText().toString()))
                .setNegativeButton("取消", null)
                .show();
    }

    private void addLines(String text) {
        String[] lines = text.replace('\r', '\n').split("\\n+");
        Set<String> existing = new HashSet<>();
        for (SourceItem item : sources) existing.add(normalizeUrl(item.url));
        int added = 0;
        int skipped = 0;
        for (String raw : lines) {
            String line = raw.trim();
            if (line.isEmpty()) continue;
            String label = "";
            String url = line;
            int split = line.indexOf('|');
            if (split > 0) {
                label = line.substring(0, split).trim();
                url = line.substring(split + 1).trim();
            }
            if (!url.matches("(?i)^https?://.+")) {
                skipped++;
                continue;
            }
            String normalized = normalizeUrl(url);
            if (existing.contains(normalized)) {
                skipped++;
                continue;
            }
            if (label.isEmpty()) label = defaultLabel(url);
            sources.add(new SourceItem(label, url, true));
            existing.add(normalized);
            added++;
        }
        saveSources();
        refreshSourceList();
        toast("已添加 " + added + " 条" + (skipped > 0 ? "，跳过 " + skipped + " 条" : ""));
    }

    private void editSource(int position) {
        SourceItem item = sources.get(position);
        EditText input = new EditText(this);
        input.setText(item.label + "|" + item.url);
        input.setSelectAllOnFocus(false);
        input.setSelection(input.length());
        input.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE | InputType.TYPE_TEXT_VARIATION_URI);
        new AlertDialog.Builder(this)
                .setTitle("修改网址")
                .setView(input)
                .setPositiveButton("保存", (d, w) -> {
                    String line = input.getText().toString().trim();
                    int split = line.indexOf('|');
                    String label = split > 0 ? line.substring(0, split).trim() : "";
                    String url = split > 0 ? line.substring(split + 1).trim() : line;
                    if (!url.matches("(?i)^https?://.+")) {
                        toast("网址格式不正确");
                        return;
                    }
                    item.label = label.isEmpty() ? defaultLabel(url) : label;
                    item.url = url;
                    saveSources();
                    refreshSourceList();
                })
                .setNegativeButton("取消", null)
                .show();
    }

    private void confirmDeleteSource(int position) {
        SourceItem item = sources.get(position);
        new AlertDialog.Builder(this)
                .setTitle("删除网址")
                .setMessage("确定删除“" + item.label + "”吗？")
                .setPositiveButton("删除", (d, w) -> {
                    sources.remove(position);
                    saveSources();
                    refreshSourceList();
                })
                .setNegativeButton("取消", null)
                .show();
    }

    private void copySourceList() {
        StringBuilder text = new StringBuilder();
        for (SourceItem item : sources) {
            if (text.length() > 0) text.append('\n');
            text.append(item.label).append('|').append(item.url);
        }
        ClipboardManager clipboard = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
        clipboard.setPrimaryClip(ClipData.newPlainText("网址清单", text.toString()));
        toast("网址清单已复制");
    }

    private void startAll() {
        ArrayList<SourceItem> enabled = new ArrayList<>();
        for (SourceItem item : sources) if (item.enabled) enabled.add(item.copy());
        if (enabled.isEmpty()) {
            toast("没有已启用的网址");
            return;
        }
        if (Build.VERSION.SDK_INT <= 28 && checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, STORAGE_REQUEST);
            return;
        }
        beginQueue(enabled, false);
    }

    private void startFailed() {
        if (failedQueue.isEmpty()) {
            toast("目前没有失败网址");
            return;
        }
        beginQueue(new ArrayList<>(failedQueue), true);
    }

    private void beginQueue(List<SourceItem> items, boolean retry) {
        captureQueue.clear();
        captureQueue.addAll(items);
        failedQueue.clear();
        captureIndex = -1;
        running = true;
        sourceScreen.setVisibility(View.GONE);
        captureScreen.setVisibility(View.VISIBLE);
        captureProgress.setMax(captureQueue.size());
        captureProgress.setProgress(0);
        loadNext();
    }

    private void loadNext() {
        if (!running) return;
        captureIndex++;
        captureProgress.setProgress(Math.min(captureIndex, captureQueue.size()));
        if (captureIndex >= captureQueue.size()) {
            finishQueue();
            return;
        }
        currentFailed = false;
        currentFailureReason = "";
        pageGeneration++;
        SourceItem item = captureQueue.get(captureIndex);
        captureStatus.setText(progressPrefix() + " 准备加载");
        captureUrl.setText(item.label + "\n" + item.url);
        webView.stopLoading();
        final int loadToken = pageGeneration;
        webView.loadUrl(item.url);
        handler.postDelayed(() -> {
            if (running && loadToken == pageGeneration && !currentFailed) {
                failCurrent("加载超时（35秒）");
            }
        }, PAGE_TIMEOUT_MS);
    }

    private String progressPrefix() {
        return "[" + Math.max(1, captureIndex + 1) + "/" + captureQueue.size() + "]";
    }

    private void scrollInnerContent(final int token, final int step, final int stablePasses) {
        if (!running || token != pageGeneration || currentFailed) return;
        captureStatus.setText(progressPrefix() + " 正在读取页面内部内容");
        String script = "(function(){" +
                "var moved=0;" +
                "function walk(doc){try{" +
                "var all=doc.querySelectorAll('*');" +
                "for(var i=0;i<all.length;i++){var el=all[i];" +
                "if(el===doc.body||el===doc.documentElement)continue;" +
                "var ch=el.clientHeight||0,sh=el.scrollHeight||0;" +
                "if(ch>60&&sh>ch+16){var before=el.scrollTop||0;" +
                "var next=Math.min(sh-ch,before+Math.max(80,Math.floor(ch*0.82)));" +
                "el.scrollTop=next;if((el.scrollTop||0)>before+1)moved++;}}" +
                "var frames=doc.querySelectorAll('iframe,frame');" +
                "for(var j=0;j<frames.length;j++){try{if(frames[j].contentDocument)walk(frames[j].contentDocument);}catch(e){}}" +
                "}catch(e){}}walk(document);return moved;})()";
        webView.evaluateJavascript(script, value -> {
            if (!running || token != pageGeneration || currentFailed) return;
            int moved = parseJavascriptInt(value);
            if (moved > 0 && step < MAX_INNER_SCROLL_STEPS) {
                handler.postDelayed(() -> scrollInnerContent(token, step + 1, 0), 170);
            } else if (stablePasses == 0 && step < MAX_INNER_SCROLL_STEPS) {
                handler.postDelayed(() -> scrollInnerContent(token, step + 1, 1), 850);
            } else {
                expandInnerContent(token);
            }
        });
    }

    private int parseJavascriptInt(String value) {
        if (value == null) return 0;
        try {
            return Integer.parseInt(value.replace("\"", "").trim());
        } catch (NumberFormatException ignored) {
            return 0;
        }
    }

    private void expandInnerContent(final int token) {
        if (!running || token != pageGeneration || currentFailed) return;
        captureStatus.setText(progressPrefix() + " 正在展开页面内部内容");
        String script = "(function(){" +
                "var expanded=0;" +
                "function force(el,key,value){try{el.style.setProperty(key,value,'important');}catch(e){}}" +
                "function walk(doc){try{" +
                "var frames=doc.querySelectorAll('iframe,frame');" +
                "for(var j=0;j<frames.length;j++){var fr=frames[j];try{" +
                "var child=fr.contentDocument;if(!child)continue;walk(child);" +
                "var de=child.documentElement,b=child.body;" +
                "var h=Math.max(de?de.scrollHeight:0,b?b.scrollHeight:0,de?de.offsetHeight:0,b?b.offsetHeight:0);" +
                "if(h>0){force(fr,'max-height','none');force(fr,'height',h+'px');force(fr,'overflow','visible');expanded++;}" +
                "}catch(e){}}" +
                "var all=doc.querySelectorAll('*');" +
                "for(var i=all.length-1;i>=0;i--){var el=all[i];" +
                "if(el===doc.body||el===doc.documentElement)continue;" +
                "var ch=el.clientHeight||0,sh=el.scrollHeight||0;" +
                "if(ch>60&&sh>ch+16){force(el,'max-height','none');force(el,'height',sh+'px');" +
                "force(el,'overflow-y','visible');el.scrollTop=0;expanded++;}}" +
                "}catch(e){}}walk(document);" +
                "try{document.documentElement.scrollTop=0;document.body.scrollTop=0;}catch(e){}" +
                "return expanded;})()";
        webView.evaluateJavascript(script, value -> {
            if (!running || token != pageGeneration || currentFailed) return;
            handler.postDelayed(() -> warmPage(token, 0, -1), 950);
        });
    }

    private void warmPage(final int token, final int step, final int previousHeight) {
        if (!running || token != pageGeneration || currentFailed) return;
        int contentHeight = Math.max(webView.getHeight(), Math.round(webView.getContentHeight() * webView.getScale()));
        int viewport = Math.max(1, webView.getHeight());
        int maxScroll = Math.max(0, contentHeight - viewport);
        int y = Math.min(maxScroll, step * Math.max(1, (int) (viewport * 0.82f)));
        captureStatus.setText(progressPrefix() + " 正在展开完整页面");
        webView.scrollTo(0, y);
        boolean atBottom = y >= maxScroll;
        if (!atBottom && step < MAX_WARM_STEPS) {
            handler.postDelayed(() -> warmPage(token, step + 1, contentHeight), 150);
            return;
        }
        if (step < MAX_WARM_STEPS && previousHeight != Integer.MIN_VALUE) {
            handler.postDelayed(() -> warmPage(token, step, Integer.MIN_VALUE), 850);
            return;
        }
        webView.scrollTo(0, 0);
        handler.postDelayed(() -> captureCurrent(token), 700);
    }

    @SuppressWarnings("deprecation")
    private void captureCurrent(final int token) {
        if (!running || token != pageGeneration || currentFailed) return;
        captureStatus.setText(progressPrefix() + " 正在生成长图");
        final Picture picture;
        try {
            picture = webView.capturePicture();
        } catch (Throwable error) {
            failCurrent("无法获取页面画面");
            return;
        }
        if (picture == null || picture.getWidth() <= 0 || picture.getHeight() <= 0) {
            failCurrent("页面内容为空");
            return;
        }
        final SourceItem item = captureQueue.get(captureIndex);
        final int queuePosition = captureIndex + 1;
        final int queueSize = captureQueue.size();
        imageExecutor.execute(() -> {
            String error = null;
            int saved = 0;
            try {
                saved = saveSinglePicture(picture, item, queuePosition, queueSize);
                if (saved == 0) error = "没有生成图片";
            } catch (OutOfMemoryError memoryError) {
                error = "页面过长，内存不足";
            } catch (Throwable throwable) {
                error = throwable.getMessage() == null ? "保存图片失败" : throwable.getMessage();
            }
            final String finalError = error;
            final int finalSaved = saved;
            handler.post(() -> {
                if (!running || token != pageGeneration) return;
                if (finalError != null) {
                    failCurrent(finalError);
                } else {
                    captureStatus.setText(progressPrefix() + " 已保存 " + finalSaved + " 张");
                    handler.postDelayed(this::loadNext, 350);
                }
            });
        });
    }

    private int saveSinglePicture(Picture picture, SourceItem item, int sourceNumber, int totalSources) throws Exception {
        float scale = OUTPUT_WIDTH / (float) picture.getWidth();
        int scaledHeight = Math.max(1, Math.round(picture.getHeight() * scale));
        int bodyHeight = Math.min(MAX_IMAGE_BODY_HEIGHT, scaledHeight);
        String timestamp = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.CHINA).format(new Date());
        Bitmap bitmap = Bitmap.createBitmap(OUTPUT_WIDTH, bodyHeight + HEADER_HEIGHT, Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(bitmap);
        canvas.drawColor(Color.WHITE);
        drawHeader(canvas, item, sourceNumber, totalSources, 1, 1, timestamp);
        canvas.save();
        canvas.clipRect(0, HEADER_HEIGHT, OUTPUT_WIDTH, HEADER_HEIGHT + bodyHeight);
        canvas.translate(0, HEADER_HEIGHT);
        canvas.scale(scale, scale);
        picture.draw(canvas);
        canvas.restore();
        String filename = String.format(Locale.CHINA, "%03d_%s.jpg", sourceNumber, safeName(item.label));
        saveBitmap(bitmap, filename);
        bitmap.recycle();
        return 1;
    }

    private void drawHeader(Canvas canvas, SourceItem item, int number, int total, int part, int parts, String timestamp) {
        Paint background = new Paint(Paint.ANTI_ALIAS_FLAG);
        background.setColor(Color.rgb(236, 245, 253));
        canvas.drawRect(0, 0, OUTPUT_WIDTH, HEADER_HEIGHT, background);
        Paint strong = new Paint(Paint.ANTI_ALIAS_FLAG);
        strong.setColor(Color.rgb(16, 72, 125));
        strong.setTextSize(31);
        strong.setFakeBoldText(true);
        Paint small = new Paint(Paint.ANTI_ALIAS_FLAG);
        small.setColor(Color.DKGRAY);
        small.setTextSize(23);
        String title = number + "/" + total + "  " + item.label + (parts > 1 ? "  第" + part + "/" + parts + "段" : "");
        canvas.drawText(ellipsize(title, strong, OUTPUT_WIDTH - 32), 16, 40, strong);
        canvas.drawText(ellipsize(timestamp + "  " + item.url, small, OUTPUT_WIDTH - 32), 16, 79, small);
        Paint line = new Paint();
        line.setColor(Color.rgb(144, 202, 249));
        line.setStrokeWidth(2);
        canvas.drawLine(0, HEADER_HEIGHT - 2, OUTPUT_WIDTH, HEADER_HEIGHT - 2, line);
    }

    private String ellipsize(String value, Paint paint, float width) {
        if (paint.measureText(value) <= width) return value;
        String suffix = "…";
        int end = value.length();
        while (end > 0 && paint.measureText(value.substring(0, end) + suffix) > width) end--;
        return value.substring(0, Math.max(0, end)) + suffix;
    }

    private void saveBitmap(Bitmap bitmap, String filename) throws Exception {
        String day = today();
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            ContentResolver resolver = getContentResolver();
            ContentValues values = new ContentValues();
            values.put(MediaStore.Images.Media.DISPLAY_NAME, filename);
            values.put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg");
            values.put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/" + ALBUM_ROOT + "/" + day);
            values.put(MediaStore.Images.Media.IS_PENDING, 1);
            Uri uri = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values);
            if (uri == null) throw new Exception("无法创建相册图片");
            try (OutputStream output = resolver.openOutputStream(uri)) {
                if (output == null || !bitmap.compress(Bitmap.CompressFormat.JPEG, 82, output)) {
                    throw new Exception("图片压缩失败");
                }
            } catch (Exception error) {
                resolver.delete(uri, null, null);
                throw error;
            }
            values.clear();
            values.put(MediaStore.Images.Media.IS_PENDING, 0);
            resolver.update(uri, values, null, null);
        } else {
            File directory = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES), ALBUM_ROOT + "/" + day);
            if (!directory.exists() && !directory.mkdirs()) throw new Exception("无法创建相册文件夹");
            File file = new File(directory, filename);
            try (OutputStream output = new FileOutputStream(file)) {
                if (!bitmap.compress(Bitmap.CompressFormat.JPEG, 82, output)) throw new Exception("图片压缩失败");
            }
            sendBroadcast(new Intent(Intent.ACTION_MEDIA_SCANNER_SCAN_FILE, Uri.fromFile(file)));
        }
    }

    private void failCurrent(String reason) {
        if (!running || currentFailed) return;
        currentFailed = true;
        currentFailureReason = reason;
        pageGeneration++;
        webView.stopLoading();
        SourceItem failed = captureQueue.get(captureIndex).copy();
        boolean exists = false;
        for (SourceItem source : failedQueue) {
            if (normalizeUrl(source.url).equals(normalizeUrl(failed.url))) {
                exists = true;
                break;
            }
        }
        if (!exists) failedQueue.add(failed);
        captureStatus.setText(progressPrefix() + " 失败：" + reason);
        handler.postDelayed(this::loadNext, 750);
    }

    private void finishQueue() {
        running = false;
        captureProgress.setProgress(captureQueue.size());
        captureStatus.setText("采集完成，失败 " + failedQueue.size() + " 条");
        webView.loadUrl("about:blank");
        handler.postDelayed(() -> {
            captureScreen.setVisibility(View.GONE);
            sourceScreen.setVisibility(View.VISIBLE);
            refreshSourceList();
            new AlertDialog.Builder(this)
                    .setTitle("采集完成")
                    .setMessage("本次处理 " + captureQueue.size() + " 个网址，失败 " + failedQueue.size() + " 个。\n图片已保存到：Pictures/" + ALBUM_ROOT + "/" + today())
                    .setPositiveButton("打开今日图片", (d, w) -> openTodayFirst())
                    .setNegativeButton("关闭", null)
                    .show();
        }, 250);
    }

    private void confirmStop() {
        new AlertDialog.Builder(this)
                .setTitle("停止采集")
                .setMessage("确定停止当前批量任务吗？已经保存的图片会保留。")
                .setPositiveButton("停止", (d, w) -> {
                    running = false;
                    pageGeneration++;
                    handler.removeCallbacksAndMessages(null);
                    webView.stopLoading();
                    webView.loadUrl("about:blank");
                    captureScreen.setVisibility(View.GONE);
                    sourceScreen.setVisibility(View.VISIBLE);
                    refreshSourceList();
                })
                .setNegativeButton("继续采集", null)
                .show();
    }

    private void openTodayFirst() {
        Uri uri = findFirstTodayImage();
        if (uri == null) {
            toast("今天还没有保存图片");
            return;
        }
        Intent intent = new Intent(Intent.ACTION_VIEW);
        intent.setDataAndType(uri, "image/*");
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        try {
            startActivity(intent);
        } catch (Exception error) {
            toast("没有找到可打开图片的相册应用");
        }
    }

    private Uri findFirstTodayImage() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) {
            File directory = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES), ALBUM_ROOT + "/" + today());
            String[] projection = {MediaStore.Images.Media._ID};
            try (Cursor cursor = getContentResolver().query(
                    MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                    projection,
                    MediaStore.Images.Media.DATA + " LIKE ?",
                    new String[]{directory.getAbsolutePath() + "/%"},
                    MediaStore.Images.Media.DISPLAY_NAME + " ASC")) {
                if (cursor != null && cursor.moveToFirst()) {
                    long id = cursor.getLong(0);
                    return ContentUris.withAppendedId(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, id);
                }
            }
            return null;
        }
        String relative = Environment.DIRECTORY_PICTURES + "/" + ALBUM_ROOT + "/" + today() + "/";
        String[] projection = {MediaStore.Images.Media._ID};
        try (Cursor cursor = getContentResolver().query(
                MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                projection,
                MediaStore.Images.Media.RELATIVE_PATH + "=?",
                new String[]{relative},
                MediaStore.Images.Media.DISPLAY_NAME + " ASC")) {
            if (cursor != null && cursor.moveToFirst()) {
                long id = cursor.getLong(0);
                return ContentUris.withAppendedId(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, id);
            }
        }
        return null;
    }

    private void confirmDeleteToday() {
        new AlertDialog.Builder(this)
                .setTitle("删除今日截图")
                .setMessage("将删除“" + today() + "”文件夹中的全部采集截图。删除后通常无法恢复，确定继续吗？")
                .setPositiveButton("全部删除", (d, w) -> deleteToday())
                .setNegativeButton("取消", null)
                .show();
    }

    private void deleteToday() {
        int deleted = 0;
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                String relative = Environment.DIRECTORY_PICTURES + "/" + ALBUM_ROOT + "/" + today() + "/";
                deleted = getContentResolver().delete(
                        MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                        MediaStore.Images.Media.RELATIVE_PATH + "=?",
                        new String[]{relative});
            } else {
                File directory = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES), ALBUM_ROOT + "/" + today());
                File[] files = directory.listFiles();
                if (files != null) {
                    for (File file : files) if (file.delete()) deleted++;
                }
                if (directory.exists()) directory.delete();
            }
            toast("已删除 " + deleted + " 张今日截图");
        } catch (Exception error) {
            toast("删除失败：" + error.getMessage());
        }
    }

    private void refreshSourceList() {
        int enabled = 0;
        for (SourceItem item : sources) if (item.enabled) enabled++;
        countText.setText("共 " + sources.size() + " 个网址，已启用 " + enabled + " 个；失败待重试 " + failedQueue.size() + " 个");
        retryButton.setEnabled(!failedQueue.isEmpty());
        adapter.notifyDataSetChanged();
    }

    private void loadSources() {
        android.content.SharedPreferences preferences = getSharedPreferences(PREFS, MODE_PRIVATE);
        if (!preferences.contains(KEY_SOURCES)) {
            saveSources();
            return;
        }
        String json = preferences.getString(KEY_SOURCES, "[]");
        try {
            JSONArray array = new JSONArray(json);
            for (int i = 0; i < array.length(); i++) {
                JSONObject object = array.getJSONObject(i);
                sources.add(new SourceItem(
                        object.optString("label", "来源" + (i + 1)),
                        object.optString("url", ""),
                        object.optBoolean("enabled", true)));
            }
        } catch (JSONException ignored) {
            sources.clear();
        }
    }

    private void saveSources() {
        JSONArray array = new JSONArray();
        for (SourceItem item : sources) {
            JSONObject object = new JSONObject();
            try {
                object.put("label", item.label);
                object.put("url", item.url);
                object.put("enabled", item.enabled);
                array.put(object);
            } catch (JSONException ignored) {
            }
        }
        getSharedPreferences(PREFS, MODE_PRIVATE).edit().putString(KEY_SOURCES, array.toString()).apply();
    }

    private String defaultLabel(String url) {
        try {
            String host = new URI(url).getHost();
            return host == null || host.isEmpty() ? "未命名来源" : host;
        } catch (Exception ignored) {
            return "未命名来源";
        }
    }

    private String normalizeUrl(String value) {
        String url = value.trim();
        while (url.endsWith("/")) url = url.substring(0, url.length() - 1);
        return url.toLowerCase(Locale.ROOT);
    }

    private String safeName(String value) {
        String clean = value.replaceAll("[\\\\/:*?\"<>|\\s]+", "_");
        if (clean.length() > 36) clean = clean.substring(0, 36);
        return clean.isEmpty() ? "未命名来源" : clean;
    }

    private String today() {
        return new SimpleDateFormat("yyyy-MM-dd", Locale.CHINA).format(new Date());
    }

    private Button button(String text, View.OnClickListener listener) {
        Button button = new Button(this);
        button.setText(text);
        button.setTextSize(13);
        button.setAllCaps(false);
        button.setOnClickListener(listener);
        button.setPadding(dp(2), 0, dp(2), 0);
        return button;
    }

    private LinearLayout buttonRow() {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        return row;
    }

    private LinearLayout.LayoutParams weightedButton() {
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(0, dp(43), 1);
        params.setMargins(dp(2), dp(2), dp(2), dp(2));
        return params;
    }

    private LinearLayout.LayoutParams matchWrap() {
        return new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
    }

    private FrameLayout.LayoutParams frameMatch() {
        return new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    private void toast(String text) {
        Toast.makeText(this, text, Toast.LENGTH_SHORT).show();
    }

    private static class SourceItem {
        String label;
        String url;
        boolean enabled;

        SourceItem(String label, String url, boolean enabled) {
            this.label = label;
            this.url = url;
            this.enabled = enabled;
        }

        SourceItem copy() {
            return new SourceItem(label, url, enabled);
        }
    }

    private class SourceAdapter extends BaseAdapter {
        @Override
        public int getCount() {
            return sources.size();
        }

        @Override
        public Object getItem(int position) {
            return sources.get(position);
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            SourceItem item = sources.get(position);
            LinearLayout row = new LinearLayout(MainActivity.this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setGravity(Gravity.CENTER_VERTICAL);
            row.setPadding(dp(2), dp(4), dp(2), dp(4));

            CheckBox enabled = new CheckBox(MainActivity.this);
            enabled.setChecked(item.enabled);
            enabled.setOnCheckedChangeListener((buttonView, isChecked) -> {
                item.enabled = isChecked;
                saveSources();
                refreshSourceList();
            });
            row.addView(enabled, new LinearLayout.LayoutParams(dp(45), dp(48)));

            LinearLayout textBox = new LinearLayout(MainActivity.this);
            textBox.setOrientation(LinearLayout.VERTICAL);
            TextView label = new TextView(MainActivity.this);
            label.setText((position + 1) + ". " + item.label);
            label.setTextSize(15);
            label.setTextColor(Color.BLACK);
            TextView url = new TextView(MainActivity.this);
            url.setText(item.url);
            url.setTextSize(11);
            url.setTextColor(Color.GRAY);
            url.setMaxLines(2);
            textBox.addView(label, matchWrap());
            textBox.addView(url, matchWrap());
            row.addView(textBox, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));

            Button edit = button("改", v -> editSource(position));
            row.addView(edit, new LinearLayout.LayoutParams(dp(54), dp(43)));
            Button delete = button("删", v -> confirmDeleteSource(position));
            row.addView(delete, new LinearLayout.LayoutParams(dp(54), dp(43)));
            return row;
        }
    }
}
