package com.zheng.websnapshot;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.ComponentCallbacks2;
import android.content.ContentResolver;
import android.content.ContentUris;
import android.content.ContentValues;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Picture;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.provider.MediaStore;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.WindowManager;
import android.webkit.CookieManager;
import android.webkit.RenderProcessGoneDetail;
import android.webkit.SslErrorHandler;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import android.net.http.SslError;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.net.URI;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.TimeZone;
import java.util.UUID;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    private static final String PREFS = "sources_v1";
    private static final String KEY_SOURCES = "sources";
    private static final String KEY_FAILURES = "failures";
    private static final String KEY_CAPTURE_SESSION = "capture_session_v1";
    private static final String ALBUM_ROOT = "六合彩资料";
    private static final int STORAGE_REQUEST = 81;
    private static final int CAPTURE_REQUEST = 82;
    private static final int OUTPUT_WIDTH = 1080;
    private static final int SHORT_IMAGE_BODY_HEIGHT = 4800;
    private static final int STANDARD_IMAGE_BODY_HEIGHT = 8000;
    private static final int HEADER_HEIGHT = 104;
    private static final long FAST_PAGE_SETTLE_MS = 1200;
    private static final long COMPAT_PAGE_SETTLE_MS = 2200;
    private static final long PAGE_TIMEOUT_MS = 12000;
    private static final int MAX_WARM_STEPS = 100;
    private static final int MAX_INNER_SCROLL_STEPS = 50;
    private static final String MODE_SMART = "smart";
    private static final String MODE_FIXED_SHORT = "fixed_short";
    private static final String LEGACY_MODE_FAST_SHORT = "fast_short";
    private static final String MODE_FAST_LONG = "fast_long";
    private static final String MODE_COMPAT_SHORT = "compat_short";
    private static final String MODE_COMPAT_LONG = "compat_long";
    private static final String GROUP_NORMAL = "normal";
    private static final String GROUP_VPN = "vpn";
    private static final String GROUP_ALL = "all";

    private final ArrayList<SourceItem> sources = new ArrayList<>();
    private final ArrayList<SourceItem> captureQueue = new ArrayList<>();
    private final ArrayList<FailureItem> failedQueue = new ArrayList<>();
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final ExecutorService imageExecutor = Executors.newSingleThreadExecutor();

    private FrameLayout root;
    private LinearLayout sourceScreen;
    private LinearLayout captureScreen;
    private SourceAdapter adapter;
    private TextView countText;
    private TextView captureStatus;
    private TextView captureUrl;
    private ProgressBar captureProgress;
    private Button failureButton;
    private Button resumeButton;
    private WebView webView;

    private int captureIndex = -1;
    private int pageGeneration = 0;
    private boolean running = false;
    private boolean currentFailed = false;
    private String currentFailureReason = "";
    private int checkpointNextIndex = 0;
    private int pendingStartPosition = 1;
    private String pendingStartGroup = GROUP_ALL;
    private boolean pendingResumeStart = false;
    private boolean workerRunning = false;
    private long workerStartedAt = 0L;
    private int workerGeneration = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        loadSources();
        loadFailures();
        buildUi();
        refreshSourceList();
        handler.postDelayed(this::promptResumeIfNeeded, 450);
    }

    @Override
    protected void onDestroy() {
        if (running) saveCaptureSession(checkpointNextIndex);
        running = false;
        pageGeneration++;
        handler.removeCallbacksAndMessages(null);
        destroyWebView();
        imageExecutor.shutdownNow();
        super.onDestroy();
    }

    @Override
    protected void onStop() {
        if (running) saveCaptureSession(checkpointNextIndex);
        super.onStop();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (!workerRunning || !running || SystemClock.elapsedRealtime() - workerStartedAt < 500L) return;
        final int token = workerGeneration;
        handler.postDelayed(() -> {
            if (!workerRunning || !running || token != workerGeneration) return;
            workerRunning = false;
            recordFailureAndAdvance("截图进程异常退出" + CaptureActivity.readLastStageSuffix(this));
        }, 700L);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != CAPTURE_REQUEST) return;
        workerRunning = false;
        workerGeneration++;
        if (!running || captureIndex < 0 || captureIndex >= captureQueue.size()) return;
        if (resultCode == CaptureActivity.RESULT_PAUSED) {
            pauseQueueFromWorker();
            return;
        }
        if (data == null) {
            recordFailureAndAdvance("截图进程异常退出" + CaptureActivity.readLastStageSuffix(this));
            return;
        }
        String detectedName = data.getStringExtra(CaptureActivity.EXTRA_DETECTED_NAME);
        if (detectedName != null && !detectedName.trim().isEmpty()) {
            applyDetectedPageName(detectedName);
        }
        if (data.getBooleanExtra(CaptureActivity.EXTRA_SUCCESS, false)) {
            SourceItem completed = captureQueue.get(captureIndex);
            boolean fallbackUsed = data.getBooleanExtra(CaptureActivity.EXTRA_FALLBACK_USED, false);
            clearFailureForSource(completed);
            currentFailed = true;
            pageGeneration++;
            saveCaptureSession(captureIndex + 1);
            captureStatus.setText(progressPrefix() + (fallbackUsed ? " 已保存顶部8000保底图" : " 已保存 1 张"));
            handler.postDelayed(this::loadNext, 650L);
        } else {
            String reason = data.getStringExtra(CaptureActivity.EXTRA_REASON);
            recordFailureAndAdvance(reason == null || reason.isEmpty() ? "截图失败" : reason);
        }
    }

    @Override
    public void onTrimMemory(int level) {
        if (running) saveCaptureSession(checkpointNextIndex);
        if (webView != null && level >= ComponentCallbacks2.TRIM_MEMORY_RUNNING_LOW) {
            try {
                webView.clearCache(false);
            } catch (Throwable ignored) {
            }
        }
        super.onTrimMemory(level);
    }

    @Override
    public void onBackPressed() {
        if (captureScreen.getVisibility() == View.VISIBLE) {
            confirmStop();
        } else {
            super.onBackPressed();
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == STORAGE_REQUEST) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                if (pendingResumeStart) {
                    resumeLastSession();
                } else {
                    startFromPosition(pendingStartPosition, pendingStartGroup);
                }
            } else {
                toast("没有存储权限，无法把截图保存到公共相册");
            }
        }
    }

    private void buildUi() {
        root = new FrameLayout(this);
        sourceScreen = new LinearLayout(this);
        sourceScreen.setOrientation(LinearLayout.VERTICAL);
        sourceScreen.setPadding(dp(8), dp(8), dp(8), dp(8));

        TextView title = new TextView(this);
        title.setText("资料长图采集");
        title.setTextSize(22);
        title.setTextColor(Color.rgb(20, 70, 120));
        title.setGravity(Gravity.CENTER_VERTICAL);
        title.setPadding(dp(4), dp(5), dp(4), dp(6));
        sourceScreen.addView(title, matchWrap());

        countText = new TextView(this);
        countText.setTextSize(14);
        countText.setTextColor(Color.DKGRAY);
        countText.setPadding(dp(4), 0, dp(4), dp(5));
        sourceScreen.addView(countText, matchWrap());

        LinearLayout row1 = buttonRow();
        row1.addView(button("添加", v -> showAddDialog(false)), weightedButton());
        row1.addView(button("批量添加", v -> showAddDialog(true)), weightedButton());
        row1.addView(button("复制清单", v -> copySourceList()), weightedButton());
        sourceScreen.addView(row1, matchWrap());

        LinearLayout row2 = buttonRow();
        row2.addView(button("开始采集", v -> showStartGroupDialog(false)), weightedButton());
        failureButton = button("失败网址", v -> showFailures());
        row2.addView(failureButton, weightedButton());
        row2.addView(button("打开今日", v -> openTodayFirst()), weightedButton());
        row2.addView(button("删除今日", v -> confirmDeleteToday()), weightedButton());
        sourceScreen.addView(row2, matchWrap());

        LinearLayout row3 = buttonRow();
        resumeButton = button("暂无未完成任务", v -> resumeLastSession());
        row3.addView(resumeButton, weightedButton());
        row3.addView(button("从指定条开始", v -> showStartGroupDialog(true)), weightedButton());
        sourceScreen.addView(row3, matchWrap());

        TextView hint = new TextView(this);
        hint.setText("每行粘贴一个网址即可。普通组和VPN组可分别运行；异常退出后会继续下一条，也可从保存断点或指定序号开始。");
        hint.setTextSize(12);
        hint.setTextColor(Color.GRAY);
        hint.setPadding(dp(4), dp(4), dp(4), dp(4));
        sourceScreen.addView(hint, matchWrap());

        ListView list = new ListView(this);
        list.setDividerHeight(dp(1));
        adapter = new SourceAdapter();
        list.setAdapter(adapter);
        sourceScreen.addView(list, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1));

        captureScreen = new LinearLayout(this);
        captureScreen.setOrientation(LinearLayout.VERTICAL);
        captureScreen.setVisibility(View.GONE);
        captureScreen.setBackgroundColor(Color.WHITE);

        captureStatus = new TextView(this);
        captureStatus.setTextSize(16);
        captureStatus.setTextColor(Color.rgb(20, 70, 120));
        captureStatus.setPadding(dp(10), dp(8), dp(10), dp(3));
        captureScreen.addView(captureStatus, matchWrap());

        captureUrl = new TextView(this);
        captureUrl.setTextSize(11);
        captureUrl.setTextColor(Color.DKGRAY);
        captureUrl.setMaxLines(2);
        captureUrl.setPadding(dp(10), 0, dp(10), dp(5));
        captureScreen.addView(captureUrl, matchWrap());

        LinearLayout progressRow = buttonRow();
        captureProgress = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        progressRow.addView(captureProgress, new LinearLayout.LayoutParams(0, dp(40), 1));
        progressRow.addView(button("停止", v -> confirmStop()), new LinearLayout.LayoutParams(dp(76), dp(40)));
        captureScreen.addView(progressRow, matchWrap());

        root.addView(sourceScreen, frameMatch());
        root.addView(captureScreen, frameMatch());
        setContentView(root);
    }

    private void ensureWebView() {
        if (webView != null) return;
        webView = new WebView(this);
        configureWebView();
        captureScreen.addView(webView, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1));
    }

    private void renewWebView() {
        destroyWebView();
        if (running) ensureWebView();
    }

    private void destroyWebView() {
        destroyWebView(webView);
    }

    private void destroyWebView(WebView target) {
        if (target == null) return;
        if (webView == target) webView = null;
        try {
            ViewParent parent = target.getParent();
            if (parent instanceof ViewGroup) ((ViewGroup) parent).removeView(target);
        } catch (Throwable ignored) {
        }
        try {
            target.stopLoading();
            target.clearHistory();
            target.clearFormData();
            target.removeAllViews();
            target.destroy();
        } catch (Throwable ignored) {
        }
    }

    private void configureWebView() {
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        // 每个网址开始加载前都会重新应用图片模式；默认先按无图处理。
        settings.setLoadsImagesAutomatically(false);
        settings.setBlockNetworkImage(true);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);
        settings.setSupportMultipleWindows(false);
        settings.setJavaScriptCanOpenWindowsAutomatically(false);
        settings.setMediaPlaybackRequiresUserGesture(true);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE);
        settings.setUserAgentString(settings.getUserAgentString() + " SnapshotReader/1.0");
        CookieManager.getInstance().setAcceptCookie(true);
        CookieManager.getInstance().setAcceptThirdPartyCookies(webView, true);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            settings.setSafeBrowsingEnabled(true);
        }
        webView.setBackgroundColor(Color.WHITE);
        webView.setLayerType(View.LAYER_TYPE_SOFTWARE, null);
        webView.setRendererPriorityPolicy(WebView.RENDERER_PRIORITY_BOUND, true);
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageStarted(WebView view, String url, Bitmap favicon) {
                currentFailed = false;
                currentFailureReason = "";
                captureStatus.setText(progressPrefix() + " 正在加载");
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                if (!running || currentFailed) return;
                final int token = ++pageGeneration;
                captureStatus.setText(progressPrefix() + " 等待页面内容");
                SourceItem item = captureQueue.get(captureIndex);
                long settleMs = isCompatibilityMode(item.captureMode) ? COMPAT_PAGE_SETTLE_MS : FAST_PAGE_SETTLE_MS;
                handler.postDelayed(() -> {
                    if (running && token == pageGeneration && !currentFailed) {
                        preparePageForCapture(token);
                    }
                }, settleMs);
            }

            @Override
            public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
                if (request.isForMainFrame()) {
                    failCurrent("网络错误：" + error.getDescription());
                }
            }

            @Override
            public void onReceivedHttpError(WebView view, WebResourceRequest request, WebResourceResponse response) {
                if (request.isForMainFrame() && response.getStatusCode() >= 400) {
                    failCurrent("HTTP " + response.getStatusCode());
                }
            }

            @Override
            public void onReceivedSslError(WebView view, SslErrorHandler handler, SslError error) {
                handler.cancel();
                failCurrent("HTTPS证书错误");
            }

            @Override
            public boolean onRenderProcessGone(WebView view, RenderProcessGoneDetail detail) {
                String reason = detail.didCrash()
                        ? "网页渲染进程崩溃"
                        : "网页占用内存过高，渲染进程被系统关闭";
                destroyWebView(view);
                if (running && !currentFailed) recordFailureAndAdvance(reason);
                return true;
            }
        });
    }

    private void showAddDialog(boolean batch) {
        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(18), 0, dp(18), 0);
        EditText input = new EditText(this);
        input.setTextSize(15);
        input.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE | InputType.TYPE_TEXT_VARIATION_URI);
        input.setMinLines(batch ? 8 : 3);
        input.setGravity(Gravity.TOP | Gravity.START);
        input.setHint(batch ? "每行一个网址\nhttps://example.com/page" : "https://example.com/page");
        content.addView(input, matchWrap());
        CheckBox vpnGroup = new CheckBox(this);
        vpnGroup.setText("添加到VPN组");
        vpnGroup.setTextSize(15);
        content.addView(vpnGroup, matchWrap());
        new AlertDialog.Builder(this)
                .setTitle(batch ? "批量添加网址" : "添加网址")
                .setView(content)
                .setPositiveButton("添加", (d, w) -> addLines(
                        input.getText().toString(),
                        vpnGroup.isChecked() ? GROUP_VPN : GROUP_NORMAL))
                .setNegativeButton("取消", null)
                .show();
    }

    private void addLines(String text, String group) {
        String[] lines = text.replace('\r', '\n').split("\\n+");
        Set<String> existing = new HashSet<>();
        for (SourceItem item : sources) existing.add(normalizeUrl(item.url));
        int added = 0;
        int skipped = 0;
        for (String raw : lines) {
            String line = raw.trim();
            if (line.isEmpty()) continue;
            String label = "";
            String url = line;
            int split = line.indexOf('|');
            if (split > 0) {
                label = line.substring(0, split).trim();
                url = line.substring(split + 1).trim();
            }
            if (!url.matches("(?i)^https?://.+")) {
                skipped++;
                continue;
            }
            String normalized = normalizeUrl(url);
            if (existing.contains(normalized)) {
                skipped++;
                continue;
            }
            boolean manualLabel = !label.isEmpty();
            if (!manualLabel) label = defaultLabel(url);
            SourceItem item = new SourceItem(label, url, true, manualLabel, MODE_SMART, manualLabel, false);
            item.group = normalizeGroup(group);
            sources.add(item);
            existing.add(normalized);
            added++;
        }
        saveSources();
        refreshSourceList();
        toast("已添加 " + added + " 条" + (skipped > 0 ? "，跳过 " + skipped + " 条" : ""));
    }

    private void editSource(int position) {
        SourceItem item = sources.get(position);
        String previousUrl = item.url;
        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(18), 0, dp(18), 0);
        EditText input = new EditText(this);
        input.setText(item.manualLabel ? item.label + "|" + item.url : item.url);
        input.setSelectAllOnFocus(false);
        input.setSelection(input.length());
        input.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE | InputType.TYPE_TEXT_VARIATION_URI);
        content.addView(input, matchWrap());
        CheckBox vpnGroup = new CheckBox(this);
        vpnGroup.setText("VPN组（需要先手动连接VPN再采集）");
        vpnGroup.setTextSize(15);
        vpnGroup.setChecked(GROUP_VPN.equals(item.group));
        content.addView(vpnGroup, matchWrap());
        new AlertDialog.Builder(this)
                .setTitle("修改网址或名称")
                .setView(content)
                .setPositiveButton("保存", (d, w) -> {
                    String line = input.getText().toString().trim();
                    int split = line.indexOf('|');
                    String label = split > 0 ? line.substring(0, split).trim() : "";
                    String url = split > 0 ? line.substring(split + 1).trim() : line;
                    if (!url.matches("(?i)^https?://.+")) {
                        toast("网址格式不正确");
                        return;
                    }
                    item.manualLabel = !label.isEmpty();
                    item.label = item.manualLabel ? label : defaultLabel(url);
                    item.nameResolved = item.manualLabel;
                    item.url = url;
                    item.group = vpnGroup.isChecked() ? GROUP_VPN : GROUP_NORMAL;
                    if (!normalizeUrl(previousUrl).equals(normalizeUrl(url))) {
                        markFailurePendingForSource(item, position, previousUrl);
                    }
                    saveSources();
                    refreshSourceList();
                })
                .setNegativeButton("取消", null)
                .show();
    }

    private void confirmDeleteSource(int position) {
        SourceItem item = sources.get(position);
        new AlertDialog.Builder(this)
                .setTitle("删除网址")
                .setMessage("确定删除“" + item.label + "”吗？")
                .setPositiveButton("删除", (d, w) -> {
                    removeFailureForSource(item);
                    sources.remove(position);
                    saveSources();
                    refreshSourceList();
                })
                .setNegativeButton("取消", null)
                .show();
    }

    private void copySourceList() {
        StringBuilder text = new StringBuilder();
        for (SourceItem item : sources) {
            if (text.length() > 0) text.append('\n');
            if (item.manualLabel) text.append(item.label).append('|');
            text.append(item.url);
        }
        ClipboardManager clipboard = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
        clipboard.setPrimaryClip(ClipData.newPlainText("网址清单", text.toString()));
        toast("网址清单已复制");
    }

    private void showStartGroupDialog(boolean askPosition) {
        String[] labels = {"普通组", "VPN组", "全部网址"};
        String[] values = {GROUP_NORMAL, GROUP_VPN, GROUP_ALL};
        new AlertDialog.Builder(this)
                .setTitle(askPosition ? "选择要从指定序号运行的分组" : "选择采集分组")
                .setItems(labels, (dialog, which) -> {
                    String group = values[which];
                    if (askPosition) showStartPositionDialog(group);
                    else startFromPosition(1, group);
                })
                .setNegativeButton("取消", null)
                .show();
    }

    private void startFromPosition(int startPosition, String requestedGroup) {
        if (sources.isEmpty()) {
            toast("网址列表为空");
            return;
        }
        String group = normalizeGroupFilter(requestedGroup);
        int safeStart = Math.max(1, Math.min(startPosition, sources.size()));
        ArrayList<SourceItem> enabled = new ArrayList<>();
        for (int i = safeStart - 1; i < sources.size(); i++) {
            SourceItem item = sources.get(i);
            if (!item.enabled) continue;
            if (!GROUP_ALL.equals(group) && !group.equals(item.group)) continue;
            SourceItem copy = item.copy();
            copy.sequenceNumber = i + 1;
            copy.sequenceTotal = sources.size();
            enabled.add(copy);
        }
        if (enabled.isEmpty()) {
            toast("从第 " + safeStart + " 条开始，" + runGroupLabel(group) + "没有已启用的网址");
            return;
        }
        if (Build.VERSION.SDK_INT <= 28 && checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            pendingStartPosition = safeStart;
            pendingStartGroup = group;
            pendingResumeStart = false;
            requestPermissions(new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, STORAGE_REQUEST);
            return;
        }
        pendingResumeStart = false;
        beginQueue(enabled, 0, false);
    }

    private void beginQueue(List<SourceItem> items, int nextIndex, boolean resumed) {
        captureQueue.clear();
        captureQueue.addAll(items);
        checkpointNextIndex = Math.max(0, Math.min(nextIndex, captureQueue.size()));
        captureIndex = checkpointNextIndex - 1;
        running = true;
        sourceScreen.setVisibility(View.GONE);
        captureScreen.setVisibility(View.VISIBLE);
        captureProgress.setMax(captureQueue.size());
        captureProgress.setProgress(checkpointNextIndex);
        saveCaptureSession(checkpointNextIndex);
        loadNext();
    }

    private void loadNext() {
        if (!running) return;
        captureIndex++;
        captureProgress.setProgress(Math.min(captureIndex, captureQueue.size()));
        if (captureIndex >= captureQueue.size()) {
            finishQueue();
            return;
        }
        checkpointNextIndex = captureIndex;
        saveCaptureSession(checkpointNextIndex);
        currentFailed = false;
        currentFailureReason = "";
        pageGeneration++;
        SourceItem item = captureQueue.get(captureIndex);
        item.resetCaptureHints();
        captureStatus.setText(progressPrefix() + " 准备加载 · " + imageModeLabel(item.loadImages));
        captureUrl.setText(item.label + " · " + imageModeLabel(item.loadImages) + "\n" + item.url);
        launchCaptureWorker(item);
    }

    private void launchCaptureWorker(SourceItem item) {
        Intent intent = new Intent(this, CaptureActivity.class);
        intent.putExtra(CaptureActivity.EXTRA_SOURCE_ID, item.sourceId);
        intent.putExtra(CaptureActivity.EXTRA_LABEL, item.label);
        intent.putExtra(CaptureActivity.EXTRA_URL, item.url);
        intent.putExtra(CaptureActivity.EXTRA_MODE, item.captureMode);
        intent.putExtra(CaptureActivity.EXTRA_LOAD_IMAGES, item.loadImages);
        intent.putExtra(CaptureActivity.EXTRA_MANUAL_LABEL, item.manualLabel);
        intent.putExtra(CaptureActivity.EXTRA_NAME_RESOLVED, item.nameResolved);
        intent.putExtra(CaptureActivity.EXTRA_SEQUENCE_NUMBER, item.sequenceNumber);
        intent.putExtra(CaptureActivity.EXTRA_SEQUENCE_TOTAL, item.sequenceTotal);
        workerRunning = true;
        workerStartedAt = SystemClock.elapsedRealtime();
        workerGeneration++;
        try {
            startActivityForResult(intent, CAPTURE_REQUEST);
        } catch (Throwable error) {
            workerRunning = false;
            recordFailureAndAdvance("无法启动截图进程");
        }
    }

    private void pauseQueueFromWorker() {
        saveCaptureSession(checkpointNextIndex);
        running = false;
        pageGeneration++;
        handler.removeCallbacksAndMessages(null);
        destroyWebView();
        captureScreen.setVisibility(View.GONE);
        sourceScreen.setVisibility(View.VISIBLE);
        refreshSourceList();
        toast("任务已暂停，可点击“继续上次”");
    }

    private String progressPrefix() {
        if (captureIndex >= 0 && captureIndex < captureQueue.size()) {
            SourceItem item = captureQueue.get(captureIndex);
            if (item.sequenceNumber > 0 && item.sequenceTotal > 0) {
                return "[" + item.sequenceNumber + "/" + item.sequenceTotal + "]";
            }
        }
        return "[" + Math.max(1, captureIndex + 1) + "/" + captureQueue.size() + "]";
    }

    private void showStartPositionDialog(String requestedGroup) {
        if (sources.isEmpty()) {
            toast("网址列表为空");
            return;
        }
        String group = normalizeGroupFilter(requestedGroup);
        EditText input = new EditText(this);
        input.setInputType(InputType.TYPE_CLASS_NUMBER);
        input.setSelectAllOnFocus(true);
        ResumeSession session = loadCaptureSession();
        int suggested = 1;
        if (session != null && session.nextIndex < session.items.size()) {
            SourceItem next = session.items.get(session.nextIndex);
            suggested = next.sequenceNumber > 0 ? next.sequenceNumber : session.nextIndex + 1;
        }
        input.setText(String.valueOf(suggested));
        String extra = session == null ? "" : "\n开始新任务后会替换当前保存的断点。";
        new AlertDialog.Builder(this)
                .setTitle(runGroupLabel(group) + "：从第几条开始")
                .setMessage("请输入总清单左侧显示的序号（1–" + sources.size() + "）。只采集该条及后面属于此分组的已启用网址。" + extra)
                .setView(input)
                .setPositiveButton("开始", (d, w) -> {
                    try {
                        int position = Integer.parseInt(input.getText().toString().trim());
                        if (position < 1 || position > sources.size()) {
                            toast("请输入 1–" + sources.size() + " 之间的序号");
                            return;
                        }
                        startFromPosition(position, group);
                    } catch (NumberFormatException error) {
                        toast("请输入正确的数字序号");
                    }
                })
                .setNegativeButton("取消", null)
                .show();
    }

    private void promptResumeIfNeeded() {
        if (running || isFinishing()) return;
        ResumeSession session = loadCaptureSession();
        if (session == null || session.nextIndex >= session.items.size()) return;
        SourceItem next = session.items.get(session.nextIndex);
        int shownNumber = next.sequenceNumber > 0 ? next.sequenceNumber : session.nextIndex + 1;
        int shownTotal = next.sequenceTotal > 0 ? next.sequenceTotal : session.items.size();
        new AlertDialog.Builder(this)
                .setTitle("发现未完成的采集任务")
                .setMessage("上次进行到第 " + shownNumber + "/" + shownTotal + " 条：\n" + next.label + "\n\n是否从这一条继续？")
                .setPositiveButton("继续上次", (d, w) -> resumeLastSession())
                .setNegativeButton("稍后", null)
                .show();
    }

    private void resumeLastSession() {
        ResumeSession session = loadCaptureSession();
        if (session == null || session.nextIndex >= session.items.size()) {
            clearCaptureSession();
            refreshSourceList();
            toast("目前没有未完成任务");
            return;
        }
        if (Build.VERSION.SDK_INT <= 28 && checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            pendingResumeStart = true;
            requestPermissions(new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, STORAGE_REQUEST);
            return;
        }
        pendingResumeStart = false;
        beginQueue(session.items, session.nextIndex, true);
    }

    private void saveCaptureSession(int nextIndex) {
        if (captureQueue.isEmpty()) return;
        int safeNext = Math.max(0, Math.min(nextIndex, captureQueue.size()));
        checkpointNextIndex = safeNext;
        JSONObject rootObject = new JSONObject();
        JSONArray queueArray = new JSONArray();
        try {
            for (SourceItem item : captureQueue) {
                JSONObject object = new JSONObject();
                object.put("sourceId", item.sourceId);
                object.put("label", item.label);
                object.put("url", item.url);
                object.put("enabled", item.enabled);
                object.put("manualLabel", item.manualLabel);
                object.put("captureMode", item.captureMode);
                object.put("nameResolved", item.nameResolved);
                object.put("loadImages", item.loadImages);
                object.put("group", item.group);
                object.put("sequenceNumber", item.sequenceNumber);
                object.put("sequenceTotal", item.sequenceTotal);
                queueArray.put(object);
            }
            rootObject.put("active", true);
            rootObject.put("savedAt", System.currentTimeMillis());
            rootObject.put("nextIndex", safeNext);
            rootObject.put("queue", queueArray);
            getSharedPreferences(PREFS, MODE_PRIVATE).edit()
                    .putString(KEY_CAPTURE_SESSION, rootObject.toString())
                    .commit();
        } catch (JSONException ignored) {
        }
    }

    private ResumeSession loadCaptureSession() {
        String json = getSharedPreferences(PREFS, MODE_PRIVATE).getString(KEY_CAPTURE_SESSION, "");
        if (json == null || json.isEmpty()) return null;
        try {
            JSONObject rootObject = new JSONObject(json);
            if (!rootObject.optBoolean("active", false)) return null;
            JSONArray queueArray = rootObject.optJSONArray("queue");
            if (queueArray == null || queueArray.length() == 0) return null;
            ArrayList<SourceItem> items = new ArrayList<>();
            for (int i = 0; i < queueArray.length(); i++) {
                JSONObject object = queueArray.getJSONObject(i);
                String url = object.optString("url", "");
                if (url.isEmpty()) continue;
                SourceItem item = new SourceItem(
                        object.optString("label", defaultLabel(url)),
                        url,
                        object.optBoolean("enabled", true),
                        object.optBoolean("manualLabel", false),
                        normalizeMode(object.optString("captureMode", MODE_SMART)),
                        object.optBoolean("nameResolved", false),
                        object.optBoolean("loadImages", false));
                item.sourceId = object.optString("sourceId", item.sourceId);
                item.group = normalizeGroup(object.optString("group", GROUP_NORMAL));
                item.sequenceNumber = object.optInt("sequenceNumber", i + 1);
                item.sequenceTotal = object.optInt("sequenceTotal", queueArray.length());
                items.add(item);
            }
            int nextIndex = Math.max(0, rootObject.optInt("nextIndex", 0));
            if (items.isEmpty() || nextIndex >= items.size()) return null;
            return new ResumeSession(items, nextIndex, rootObject.optLong("savedAt", 0L));
        } catch (JSONException ignored) {
            return null;
        }
    }

    private void clearCaptureSession() {
        checkpointNextIndex = 0;
        getSharedPreferences(PREFS, MODE_PRIVATE).edit().remove(KEY_CAPTURE_SESSION).commit();
    }

    private void applyImageLoadingMode(boolean loadImages) {
        WebSettings settings = webView.getSettings();
        if (loadImages) {
            settings.setBlockNetworkImage(false);
            settings.setLoadsImagesAutomatically(true);
        } else {
            settings.setLoadsImagesAutomatically(false);
            settings.setBlockNetworkImage(true);
        }
    }

    private void preparePageForCapture(final int token) {
        if (!running || token != pageGeneration || currentFailed) return;
        SourceItem current = captureQueue.get(captureIndex);
        if (current.loadImages) {
            detectPageName(token);
            return;
        }
        captureStatus.setText(progressPrefix() + " 正在整理无图页面");
        String script = "(function(){" +
                "function clean(doc){try{" +
                "if(!doc||!doc.documentElement)return;" +
                "var old=doc.getElementById('__snapshot_no_image__');" +
                "if(!old){var s=doc.createElement('style');s.id='__snapshot_no_image__';" +
                "s.textContent='img,picture,video,source,input[type=image]{display:none!important;}*{background-image:none!important;}';" +
                "(doc.head||doc.documentElement).appendChild(s);}" +
                "var frames=doc.querySelectorAll('iframe,frame');" +
                "for(var j=0;j<frames.length;j++){try{clean(frames[j].contentDocument);}catch(e){}}" +
                "}catch(e){}}clean(document);return true;})()";
        webView.evaluateJavascript(script, value -> {
            if (running && token == pageGeneration && !currentFailed) detectPageName(token);
        });
    }

    private void detectPageName(final int token) {
        if (!running || token != pageGeneration || currentFailed) return;
        SourceItem current = captureQueue.get(captureIndex);
        if (current.manualLabel || current.nameResolved) {
            continueAfterNameDetection(token);
            return;
        }
        captureStatus.setText(progressPrefix() + " 正在识别网站名称");
        String script = "(function(){" +
                "function clean(v){return (v||'').replace(/\\s+/g,' ').trim();}" +
                "function generic(v){return !v||/^(首页|主页|home|index|welcome|document|untitled)$/i.test(v);}" +
                "function pick(doc){try{var t=clean(doc.title);if(!generic(t))return t;" +
                "var list=doc.querySelectorAll('h1,h2,.logo,.site-title,.title');" +
                "for(var i=0;i<list.length;i++){var s=clean(list[i].innerText||list[i].textContent);" +
                "if(s.length>=2&&s.length<=60&&!generic(s))return s;}}catch(e){}return '';}" +
                "var result=pick(document);if(result)return result;" +
                "var frames=document.querySelectorAll('iframe,frame');" +
                "for(var i=0;i<frames.length;i++){try{var s=pick(frames[i].contentDocument);if(s)return s;}catch(e){}}" +
                "return '';})()";
        webView.evaluateJavascript(script, value -> {
            if (!running || token != pageGeneration || currentFailed) return;
            applyDetectedPageName(decodeJavascriptString(value));
            continueAfterNameDetection(token);
        });
    }

    private void continueAfterNameDetection(final int token) {
        SourceItem item = captureQueue.get(captureIndex);
        if (isCompatibilityMode(item.captureMode)) {
            scrollInnerContent(token, 0, 0);
        } else {
            expandInnerContent(token, false);
        }
    }

    private String decodeJavascriptString(String value) {
        if (value == null || "null".equals(value)) return "";
        try {
            return new JSONArray("[" + value + "]").getString(0);
        } catch (JSONException ignored) {
            return value.replace("\"", "").trim();
        }
    }

    private void applyDetectedPageName(String detected) {
        if (captureIndex < 0 || captureIndex >= captureQueue.size()) return;
        SourceItem queueItem = captureQueue.get(captureIndex);
        if (queueItem.manualLabel) return;
        String clean = detected == null ? "" : detected.replaceAll("\\s+", " ").trim();
        if (clean.length() > 40) clean = clean.substring(0, 40).trim();
        if (clean.length() < 2 || clean.matches("(?i)^(首页|主页|home|index|welcome|document|untitled)$") || clean.matches("(?i)^https?://.*")) {
            return;
        }
        queueItem.label = clean;
        queueItem.nameResolved = true;
        for (SourceItem source : sources) {
            if (!source.manualLabel && (source.sourceId.equals(queueItem.sourceId) || normalizeUrl(source.url).equals(normalizeUrl(queueItem.url)))) {
                source.label = clean;
                source.nameResolved = true;
                break;
            }
        }
        captureUrl.setText(queueItem.label + " · " + imageModeLabel(queueItem.loadImages) + "\n" + queueItem.url);
        saveSources();
    }

    private boolean isCompatibilityMode(String mode) {
        return MODE_COMPAT_SHORT.equals(mode) || MODE_COMPAT_LONG.equals(mode);
    }

    private boolean isLongMode(String mode) {
        return MODE_FAST_LONG.equals(mode) || MODE_COMPAT_LONG.equals(mode);
    }

    private String normalizeMode(String mode) {
        if (MODE_FIXED_SHORT.equals(mode) || MODE_FAST_LONG.equals(mode) || MODE_COMPAT_SHORT.equals(mode) || MODE_COMPAT_LONG.equals(mode)) return mode;
        if (MODE_SMART.equals(mode) || LEGACY_MODE_FAST_SHORT.equals(mode)) return MODE_SMART;
        return MODE_SMART;
    }

    private String normalizeGroup(String group) {
        return GROUP_VPN.equalsIgnoreCase(valueOrEmpty(group)) ? GROUP_VPN : GROUP_NORMAL;
    }

    private String normalizeGroupFilter(String group) {
        return GROUP_ALL.equalsIgnoreCase(valueOrEmpty(group)) ? GROUP_ALL : normalizeGroup(group);
    }

    private String runGroupLabel(String group) {
        if (GROUP_VPN.equals(group)) return "VPN组";
        if (GROUP_NORMAL.equals(group)) return "普通组";
        return "全部网址";
    }

    private String valueOrEmpty(String value) {
        return value == null ? "" : value.trim();
    }

    private String modeLabel(String mode) {
        if (MODE_SMART.equals(mode)) return "智能";
        if (MODE_FIXED_SHORT.equals(mode)) return "短图";
        if (MODE_FAST_LONG.equals(mode)) return "速长";
        if (MODE_COMPAT_SHORT.equals(mode)) return "兼短";
        if (MODE_COMPAT_LONG.equals(mode)) return "兼长";
        return "智能";
    }

    private String imageModeLabel(boolean loadImages) {
        return loadImages ? "有图" : "无图";
    }

    private void scrollInnerContent(final int token, final int step, final int stablePasses) {
        if (!running || token != pageGeneration || currentFailed) return;
        captureStatus.setText(progressPrefix() + " 正在读取页面内部内容");
        String script = "(function(){" +
                "var moved=0;" +
                "function walk(doc){try{" +
                "var all=doc.querySelectorAll('*');" +
                "for(var i=0;i<all.length;i++){var el=all[i];" +
                "if(el===doc.body||el===doc.documentElement)continue;" +
                "var ch=el.clientHeight||0,sh=el.scrollHeight||0;" +
                "if(ch>60&&sh>ch+16){var before=el.scrollTop||0;" +
                "var next=Math.min(sh-ch,before+Math.max(80,Math.floor(ch*0.82)));" +
                "el.scrollTop=next;if((el.scrollTop||0)>before+1)moved++;}}" +
                "var frames=doc.querySelectorAll('iframe,frame');" +
                "for(var j=0;j<frames.length;j++){try{if(frames[j].contentDocument)walk(frames[j].contentDocument);}catch(e){}}" +
                "}catch(e){}}walk(document);return moved;})()";
        webView.evaluateJavascript(script, value -> {
            if (!running || token != pageGeneration || currentFailed) return;
            int moved = parseJavascriptInt(value);
            if (moved > 0 && step < MAX_INNER_SCROLL_STEPS) {
                handler.postDelayed(() -> scrollInnerContent(token, step + 1, 0), 170);
            } else if (stablePasses == 0 && step < MAX_INNER_SCROLL_STEPS) {
                handler.postDelayed(() -> scrollInnerContent(token, step + 1, 1), 850);
            } else {
                expandInnerContent(token, true);
            }
        });
    }

    private int parseJavascriptInt(String value) {
        if (value == null) return 0;
        try {
            return Integer.parseInt(value.replace("\"", "").trim());
        } catch (NumberFormatException ignored) {
            return 0;
        }
    }

    private void expandInnerContent(final int token, final boolean compatibilityMode) {
        if (!running || token != pageGeneration || currentFailed) return;
        captureStatus.setText(progressPrefix() + " 正在识别展示区和最新期号");
        String script = "(function(){var expected=" + expectedIssueNumber() + ";" + """
                var expanded=0,documents=[],candidates=[],markers=[];
                function force(el,key,value){try{el.style.setProperty(key,value,'important');}catch(e){}}
                function pushCandidate(el,kind,contentHeight){
                  if(!el)return;
                  for(var i=0;i<candidates.length;i++)if(candidates[i].el===el){
                    if((contentHeight||0)>candidates[i].contentHeight)candidates[i].contentHeight=contentHeight||0;
                    if(kind==='scroll'||kind==='frame')candidates[i].kind=kind;
                    return;
                  }
                  candidates.push({el:el,kind:kind,contentHeight:contentHeight||0});
                }
                function walk(doc){try{
                  if(!doc||!doc.documentElement)return;
                  documents.push(doc);
                  var frames=doc.querySelectorAll('iframe,frame');
                  for(var j=0;j<frames.length;j++){var fr=frames[j];try{
                    var child=fr.contentDocument;if(!child)continue;walk(child);
                    var de=child.documentElement,b=child.body;
                    var h=Math.max(de?de.scrollHeight:0,b?b.scrollHeight:0,de?de.offsetHeight:0,b?b.offsetHeight:0);
                    pushCandidate(fr,'frame',h);
                    if(h>0){force(fr,'max-height','none');force(fr,'height',h+'px');force(fr,'overflow','visible');expanded++;}
                  }catch(e){}}
                  var all=doc.querySelectorAll('*');
                  for(var i=all.length-1;i>=0;i--){var el=all[i];
                    if(el===doc.body||el===doc.documentElement)continue;
                    var ch=el.clientHeight||0,sh=el.scrollHeight||0,cw=el.clientWidth||0;
                    if(ch>60&&sh>ch+16&&cw>120){
                      pushCandidate(el,'scroll',sh);
                      force(el,'max-height','none');force(el,'height',sh+'px');
                      force(el,'overflow-y','visible');el.scrollTop=0;expanded++;
                    }
                  }
                }catch(e){}}
                function rootBoxFrom(doc,r){
                  var win=doc.defaultView,left=r.left+(win.pageXOffset||0),top=r.top+(win.pageYOffset||0);
                  var width=r.width||Math.max(0,r.right-r.left),height=r.height||Math.max(0,r.bottom-r.top);
                  try{while(win&&win.frameElement){
                    var fr=win.frameElement,pdoc=fr.ownerDocument,pwin=pdoc.defaultView,br=fr.getBoundingClientRect();
                    left+=br.left+(pwin.pageXOffset||0);top+=br.top+(pwin.pageYOffset||0);win=pwin;
                  }}catch(e){}
                  return {left:left,top:top,width:width,height:height,right:left+width,bottom:top+height};
                }
                function rootBox(el,contentHeight){
                  try{var r=el.getBoundingClientRect(),b=rootBoxFrom(el.ownerDocument,r);
                    var h=Math.max(b.height,contentHeight||0,el.scrollHeight||0);
                    var w=Math.max(b.width,Math.min(el.scrollWidth||0,Math.max(b.width,document.documentElement.clientWidth||b.width)));
                    b.width=w;b.height=h;b.right=b.left+w;b.bottom=b.top+h;return b;
                  }catch(e){return null;}
                }
                function visible(el){try{var s=el.ownerDocument.defaultView.getComputedStyle(el);return s.display!=='none'&&s.visibility!=='hidden';}catch(e){return true;}}
                function addMarker(n,doc,r,el){
                  if(n<1||n>366||!r||!el||!visible(el))return;
                  var b=rootBoxFrom(doc,r);
                  if(b.width<1&&b.height<1)return;
                  markers.push({n:n,y:b.top+b.height/2,h:Math.max(1,b.height),el:el});
                }
                function scan(doc){try{
                  var root=doc.body||doc.documentElement;if(!root)return;
                  var walker=doc.createTreeWalker(root,4,null),node,count=0,re=/(?:第\\s*)?(\\d{1,3})\\s*期/g;
                  while((node=walker.nextNode())&&count<30000&&markers.length<800){count++;
                    var parent=node.parentElement;if(!parent||/^(SCRIPT|STYLE|NOSCRIPT|TEXTAREA)$/i.test(parent.tagName))continue;
                    var value=node.nodeValue||'',match;re.lastIndex=0;
                    while((match=re.exec(value))!==null){try{
                      var range=doc.createRange();range.setStart(node,match.index);range.setEnd(node,re.lastIndex);
                      addMarker(parseInt(match[1],10),doc,range.getBoundingClientRect(),parent);
                    }catch(e){}if(match[0].length===0)re.lastIndex++;}
                  }
                  var tagged=doc.querySelectorAll('[alt],[title]');
                  for(var i=0;i<tagged.length&&markers.length<800;i++){
                    var text=(tagged[i].getAttribute('alt')||'')+' '+(tagged[i].getAttribute('title')||''),m;re.lastIndex=0;
                    while((m=re.exec(text))!==null){addMarker(parseInt(m[1],10),doc,tagged[i].getBoundingClientRect(),tagged[i]);if(m[0].length===0)re.lastIndex++;}
                  }
                }catch(e){}}
                function addSemantic(doc){try{
                  var list=doc.querySelectorAll('main,article,[role=main],#content,#main,#container,.content,.main,.container,.list,.data,.info,.article,.detail,table');
                  for(var i=0;i<list.length;i++)pushCandidate(list[i],'semantic',0);
                  pushCandidate(doc.body||doc.documentElement,'root',0);
                }catch(e){}}
                function inside(m,b){return m.y>=b.top-2&&m.y<=b.bottom+2;}
                function issueDistance(n){
                  var d=Math.abs(n-expected);
                  if(expected<=20&&n>=340)d=expected+(366-n)+3;
                  if(n>expected+3&&!(expected<=20&&n>=340))d+=18;
                  return d;
                }
                function lagDistance(n){
                  var lag=expected-n;
                  if(lag>=0)return lag;
                  if(expected<=20&&n>=340)return expected+(366-n);
                  return 1000+Math.abs(lag);
                }
                function analyze(box){
                  var raw=[],list=[],seen={},uniqueCount=0;
                  for(var i=0;i<markers.length;i++)if(inside(markers[i],box))raw.push(markers[i]);
                  raw.sort(function(a,b){return a.y-b.y;});
                  for(var r=0;r<raw.length;r++){
                    var previous=list.length?list[list.length-1]:null;
                    if(previous&&previous.n===raw[r].n&&Math.abs(previous.y-raw[r].y)<4)continue;
                    list.push(raw[r]);if(!seen[raw[r].n]){seen[raw[r].n]=true;uniqueCount++;}
                  }
                  var inc=0,dec=0;
                  for(var j=1;j<list.length;j++){var before=list[j-1].n,after=list[j].n,diff=after-before;
                    if((diff>0&&diff<=30)||(before>=340&&after<=20))inc++;
                    else if((diff<0&&diff>=-30)||(before<=20&&after>=340))dec++;
                  }
                  var direction=inc>dec?1:(dec>inc?-1:0),best=null,bestDistance=9999;
                  if(direction>0){
                    for(var k=list.length-1;k>=0;k--){var lag=lagDistance(list[k].n);if(lag<=45){best=list[k];bestDistance=lag;break;}}
                  }else if(direction<0){
                    for(var k=0;k<list.length;k++){var lag=lagDistance(list[k].n);if(lag<=45){best=list[k];bestDistance=lag;break;}}
                  }
                  if(!best){for(var k=0;k<list.length;k++){var dist=issueDistance(list[k].n);if(dist<bestDistance){bestDistance=dist;best=list[k];}}}
                  return {list:list,uniqueCount:uniqueCount,inc:inc,dec:dec,direction:direction,best:best,distance:bestDistance};
                }
                walk(document);
                for(var d=0;d<documents.length;d++){addSemantic(documents[d]);scan(documents[d]);}
                var near=null,nearDistance=9999;
                for(var mi=0;mi<markers.length;mi++){var md=issueDistance(markers[mi].n);if(md<nearDistance){nearDistance=md;near=markers[mi];}}
                if(near){var ancestor=near.el;for(var level=0;ancestor&&level<10;level++,ancestor=ancestor.parentElement)pushCandidate(ancestor,'ancestor',0);}
                var chosen=null,chosenBox=null,chosenAnalysis=null,chosenScore=-1e20;
                for(var c=0;c<candidates.length;c++){
                  var candidate=candidates[c],box=rootBox(candidate.el,candidate.contentHeight);
                  if(!box||box.width<120||box.height<160)continue;
                  var a=analyze(box),kindBonus=candidate.kind==='scroll'?9000:(candidate.kind==='frame'?7600:(candidate.kind==='semantic'?4800:(candidate.kind==='ancestor'?3200:0)));
                  var sequence=a.inc+a.dec,close=a.best?Math.max(0,2400-a.distance*100):0;
                  var score=kindBonus+Math.min(24,a.uniqueCount)*420+sequence*2600+close-Math.min(1800,box.height/22);
                  if(a.uniqueCount<2)score-=3500;
                  if(score>chosenScore){chosenScore=score;chosen=candidate;chosenBox=box;chosenAnalysis=a;}
                }
                if(!chosenBox){
                  var de=document.documentElement,b=document.body,w=Math.max(de?de.scrollWidth:0,b?b.scrollWidth:0,de?de.clientWidth:0);
                  var h=Math.max(de?de.scrollHeight:0,b?b.scrollHeight:0,de?de.clientHeight:0);
                  chosenBox={left:0,top:0,width:w,height:h,right:w,bottom:h};chosenAnalysis=analyze(chosenBox);
                }
                var reliable=chosenAnalysis&&chosenAnalysis.best&&chosenAnalysis.uniqueCount>=2&&(chosenAnalysis.inc+chosenAnalysis.dec>=1||chosenAnalysis.distance<=2);
                var latest=reliable?chosenAnalysis.best:null,atBottom=false,issueTop=0,issueHeight=0;
                if(latest){
                  if(chosenAnalysis.direction>0){issueTop=latest.y;atBottom=true;}
                  else if(chosenAnalysis.direction<0){issueTop=latest.y;atBottom=false;}
                  else{issueTop=latest.y;atBottom=issueTop>chosenBox.top+chosenBox.height/2;}
                  issueHeight=latest.h;issueTop-=issueHeight/2;
                }
                var rootDe=document.documentElement,rootBody=document.body;
                var docWidth=Math.max(rootDe?rootDe.scrollWidth:0,rootBody?rootBody.scrollWidth:0,rootDe?rootDe.clientWidth:0);
                var docHeight=Math.max(rootDe?rootDe.scrollHeight:0,rootBody?rootBody.scrollHeight:0,rootDe?rootDe.clientHeight:0);
                var margin=6,left=Math.max(0,chosenBox.left-margin),top=Math.max(0,chosenBox.top-margin);
                var width=Math.min(docWidth-left,chosenBox.width+margin*2),height=Math.min(docHeight-top,chosenBox.height+margin*2);
                try{document.documentElement.scrollTop=0;if(document.body)document.body.scrollTop=0;}catch(e){}
                return JSON.stringify({expanded:expanded,regionFound:width>120&&height>160,left:left,top:top,width:width,height:height,
                  latestFound:!!latest,issue:latest?latest.n:0,issueTop:issueTop,issueHeight:issueHeight,atBottom:atBottom,
                  direction:chosenAnalysis?chosenAnalysis.direction:0,docWidth:docWidth,docHeight:docHeight});
                })()
                """;
        webView.evaluateJavascript(script, value -> {
            if (!running || token != pageGeneration || currentFailed) return;
            applyCaptureLayoutResult(value);
            if (compatibilityMode) {
                handler.postDelayed(() -> warmPage(token, 0, -1), 850);
            } else {
                webView.scrollTo(0, 0);
                handler.postDelayed(() -> captureCurrent(token), 550);
            }
        });
    }

    private int expectedIssueNumber() {
        Calendar calendar = Calendar.getInstance(TimeZone.getTimeZone("Asia/Shanghai"), Locale.CHINA);
        return calendar.get(Calendar.DAY_OF_YEAR);
    }

    private void applyCaptureLayoutResult(String value) {
        if (captureIndex < 0 || captureIndex >= captureQueue.size()) return;
        SourceItem item = captureQueue.get(captureIndex);
        try {
            JSONObject result = new JSONObject(decodeJavascriptString(value));
            item.captureRegionFound = result.optBoolean("regionFound", false);
            item.captureRegionLeft = (float) result.optDouble("left", 0d);
            item.captureRegionTop = (float) result.optDouble("top", 0d);
            item.captureRegionWidth = (float) result.optDouble("width", 0d);
            item.captureRegionHeight = (float) result.optDouble("height", 0d);
            item.captureDocumentWidth = (float) result.optDouble("docWidth", 0d);
            item.captureDocumentHeight = (float) result.optDouble("docHeight", 0d);
            item.latestIssueFound = result.optBoolean("latestFound", false);
            item.latestIssueNumber = result.optInt("issue", 0);
            item.latestIssueTop = (float) result.optDouble("issueTop", 0d);
            item.latestIssueHeight = (float) result.optDouble("issueHeight", 0d);
            item.latestIssueAtBottom = result.optBoolean("atBottom", false);
        } catch (JSONException ignored) {
            item.resetCaptureHints();
        }
    }

    private void warmPage(final int token, final int step, final int previousHeight) {
        if (!running || token != pageGeneration || currentFailed) return;
        int contentHeight = Math.max(webView.getHeight(), Math.round(webView.getContentHeight() * webView.getScale()));
        int viewport = Math.max(1, webView.getHeight());
        int maxScroll = Math.max(0, contentHeight - viewport);
        int y = Math.min(maxScroll, step * Math.max(1, (int) (viewport * 0.82f)));
        captureStatus.setText(progressPrefix() + " 正在展开完整页面");
        webView.scrollTo(0, y);
        boolean atBottom = y >= maxScroll;
        if (!atBottom && step < MAX_WARM_STEPS) {
            handler.postDelayed(() -> warmPage(token, step + 1, contentHeight), 150);
            return;
        }
        if (step < MAX_WARM_STEPS && previousHeight != Integer.MIN_VALUE) {
            handler.postDelayed(() -> warmPage(token, step, Integer.MIN_VALUE), 850);
            return;
        }
        webView.scrollTo(0, 0);
        handler.postDelayed(() -> captureCurrent(token), 700);
    }

    @SuppressWarnings("deprecation")
    private void captureCurrent(final int token) {
        if (!running || token != pageGeneration || currentFailed) return;
        captureStatus.setText(progressPrefix() + " 正在生成长图");
        final Picture picture;
        try {
            picture = webView.capturePicture();
        } catch (Throwable error) {
            failCurrent("无法获取页面画面");
            return;
        }
        if (picture == null || picture.getWidth() <= 0 || picture.getHeight() <= 0) {
            failCurrent("页面内容为空");
            return;
        }
        final SourceItem item = captureQueue.get(captureIndex);
        final int queuePosition = item.sequenceNumber > 0 ? item.sequenceNumber : captureIndex + 1;
        final int queueSize = item.sequenceTotal > 0 ? item.sequenceTotal : captureQueue.size();
        imageExecutor.execute(() -> {
            String error = null;
            int saved = 0;
            try {
                saved = saveSinglePicture(picture, item, queuePosition, queueSize);
                if (saved == 0) error = "没有生成图片";
            } catch (OutOfMemoryError memoryError) {
                error = "页面过长，内存不足";
            } catch (Throwable throwable) {
                error = throwable.getMessage() == null ? "保存图片失败" : throwable.getMessage();
            }
            final String finalError = error;
            final int finalSaved = saved;
            handler.post(() -> {
                if (!running || token != pageGeneration) return;
                if (finalError != null) {
                    failCurrent(finalError);
                } else {
                    currentFailed = true;
                    pageGeneration++;
                    saveCaptureSession(captureIndex + 1);
                    captureStatus.setText(progressPrefix() + " 已保存 " + finalSaved + " 张");
                    handler.postDelayed(() -> {
                        if (!running) return;
                        renewWebView();
                        loadNext();
                    }, 450);
                }
            });
        });
    }

    private int saveSinglePicture(Picture picture, SourceItem item, int sourceNumber, int totalSources) throws Exception {
        float coordinateScaleX = item.captureDocumentWidth > 0f ? picture.getWidth() / item.captureDocumentWidth : 1f;
        float coordinateScaleY = item.captureDocumentHeight > 0f ? picture.getHeight() / item.captureDocumentHeight : coordinateScaleX;
        float regionLeft = 0f;
        float regionTop = 0f;
        float regionWidth = picture.getWidth();
        float regionHeight = picture.getHeight();
        if (item.captureRegionFound && item.captureRegionWidth > 16f && item.captureRegionHeight > 32f) {
            regionLeft = Math.max(0f, Math.min(item.captureRegionLeft * coordinateScaleX, picture.getWidth() - 1f));
            regionTop = Math.max(0f, Math.min(item.captureRegionTop * coordinateScaleY, picture.getHeight() - 1f));
            regionWidth = Math.max(1f, Math.min(item.captureRegionWidth * coordinateScaleX, picture.getWidth() - regionLeft));
            regionHeight = Math.max(1f, Math.min(item.captureRegionHeight * coordinateScaleY, picture.getHeight() - regionTop));
        }
        float latestIssueTop = item.latestIssueTop * coordinateScaleY;
        float latestIssueHeight = item.latestIssueHeight * coordinateScaleY;
        float baseScale = OUTPUT_WIDTH / regionWidth;
        int naturalHeight = Math.max(1, Math.round(regionHeight * baseScale));
        float drawScale = baseScale;
        float cropTop = regionTop;
        int bodyHeight;
        if (MODE_SMART.equals(item.captureMode)) {
            if (naturalHeight <= SHORT_IMAGE_BODY_HEIGHT) {
                bodyHeight = naturalHeight;
            } else if (item.latestIssueFound) {
                bodyHeight = SHORT_IMAGE_BODY_HEIGHT;
                cropTop = chooseRelevantCropTop(regionTop, regionHeight, bodyHeight / baseScale, latestIssueTop, latestIssueHeight, item.latestIssueAtBottom);
            } else if (naturalHeight <= STANDARD_IMAGE_BODY_HEIGHT) {
                bodyHeight = naturalHeight;
            } else {
                bodyHeight = STANDARD_IMAGE_BODY_HEIGHT;
                drawScale = bodyHeight / regionHeight;
            }
        } else {
            int requestedHeight = isLongMode(item.captureMode) ? STANDARD_IMAGE_BODY_HEIGHT : SHORT_IMAGE_BODY_HEIGHT;
            bodyHeight = Math.min(requestedHeight, naturalHeight);
            if (naturalHeight > bodyHeight && item.latestIssueFound) {
                cropTop = chooseRelevantCropTop(regionTop, regionHeight, bodyHeight / baseScale, latestIssueTop, latestIssueHeight, item.latestIssueAtBottom);
            }
        }
        float renderedWidth = regionWidth * drawScale;
        float drawX = (OUTPUT_WIDTH - renderedWidth) / 2f - regionLeft * drawScale;
        float drawY = HEADER_HEIGHT - cropTop * drawScale;
        String timestamp = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.CHINA).format(new Date());
        Bitmap bitmap = null;
        try {
            bitmap = Bitmap.createBitmap(OUTPUT_WIDTH, bodyHeight + HEADER_HEIGHT, Bitmap.Config.RGB_565);
            Canvas canvas = new Canvas(bitmap);
            canvas.drawColor(Color.WHITE);
            drawHeader(canvas, item, sourceNumber, totalSources, 1, 1, timestamp);
            canvas.save();
            canvas.clipRect(0, HEADER_HEIGHT, OUTPUT_WIDTH, HEADER_HEIGHT + bodyHeight);
            canvas.translate(drawX, drawY);
            canvas.scale(drawScale, drawScale);
            picture.draw(canvas);
            canvas.restore();
            String filename = String.format(Locale.CHINA, "%03d_%s.jpg", sourceNumber, safeName(item.label));
            saveBitmap(bitmap, filename);
            return 1;
        } finally {
            if (bitmap != null && !bitmap.isRecycled()) bitmap.recycle();
        }
    }

    private float chooseRelevantCropTop(float regionTop, float regionHeight, float windowHeight, float latestIssueTop, float latestIssueHeight, boolean latestAtBottom) {
        float regionBottom = regionTop + regionHeight;
        float latestCenter = latestIssueTop + Math.max(1f, latestIssueHeight) / 2f;
        float desired = latestAtBottom ? regionBottom - windowHeight : regionTop;
        if (latestCenter < desired || latestCenter > desired + windowHeight) {
            desired = latestCenter - windowHeight / 2f;
        }
        return Math.max(regionTop, Math.min(desired, regionBottom - windowHeight));
    }

    private void drawHeader(Canvas canvas, SourceItem item, int number, int total, int part, int parts, String timestamp) {
        Paint background = new Paint(Paint.ANTI_ALIAS_FLAG);
        background.setColor(Color.rgb(236, 245, 253));
        canvas.drawRect(0, 0, OUTPUT_WIDTH, HEADER_HEIGHT, background);
        Paint strong = new Paint(Paint.ANTI_ALIAS_FLAG);
        strong.setColor(Color.rgb(16, 72, 125));
        strong.setTextSize(31);
        strong.setFakeBoldText(true);
        Paint small = new Paint(Paint.ANTI_ALIAS_FLAG);
        small.setColor(Color.DKGRAY);
        small.setTextSize(23);
        String issueHint = item.latestIssueFound && item.latestIssueNumber > 0
                ? "  定位" + item.latestIssueNumber + "期" + (item.latestIssueAtBottom ? "·下部" : "·上部")
                : "";
        String title = number + "/" + total + "  " + item.label + issueHint + (parts > 1 ? "  第" + part + "/" + parts + "段" : "");
        canvas.drawText(ellipsize(title, strong, OUTPUT_WIDTH - 32), 16, 40, strong);
        canvas.drawText(ellipsize(timestamp + "  " + item.url, small, OUTPUT_WIDTH - 32), 16, 79, small);
        Paint line = new Paint();
        line.setColor(Color.rgb(144, 202, 249));
        line.setStrokeWidth(2);
        canvas.drawLine(0, HEADER_HEIGHT - 2, OUTPUT_WIDTH, HEADER_HEIGHT - 2, line);
    }

    private String ellipsize(String value, Paint paint, float width) {
        if (paint.measureText(value) <= width) return value;
        String suffix = "…";
        int end = value.length();
        while (end > 0 && paint.measureText(value.substring(0, end) + suffix) > width) end--;
        return value.substring(0, Math.max(0, end)) + suffix;
    }

    private void saveBitmap(Bitmap bitmap, String filename) throws Exception {
        String day = today();
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            ContentResolver resolver = getContentResolver();
            ContentValues values = new ContentValues();
            values.put(MediaStore.Images.Media.DISPLAY_NAME, filename);
            values.put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg");
            values.put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/" + ALBUM_ROOT + "/" + day);
            values.put(MediaStore.Images.Media.IS_PENDING, 1);
            Uri uri = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values);
            if (uri == null) throw new Exception("无法创建相册图片");
            try (OutputStream output = resolver.openOutputStream(uri)) {
                if (output == null || !bitmap.compress(Bitmap.CompressFormat.JPEG, 82, output)) {
                    throw new Exception("图片压缩失败");
                }
            } catch (Exception error) {
                resolver.delete(uri, null, null);
                throw error;
            }
            values.clear();
            values.put(MediaStore.Images.Media.IS_PENDING, 0);
            resolver.update(uri, values, null, null);
        } else {
            File directory = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES), ALBUM_ROOT + "/" + day);
            if (!directory.exists() && !directory.mkdirs()) throw new Exception("无法创建相册文件夹");
            File file = new File(directory, filename);
            try (OutputStream output = new FileOutputStream(file)) {
                if (!bitmap.compress(Bitmap.CompressFormat.JPEG, 82, output)) throw new Exception("图片压缩失败");
            }
            sendBroadcast(new Intent(Intent.ACTION_MEDIA_SCANNER_SCAN_FILE, Uri.fromFile(file)));
        }
    }

    private void failCurrent(String reason) {
        if (!running || currentFailed) return;
        if (webView != null) {
            try {
                webView.stopLoading();
            } catch (Throwable ignored) {
            }
        }
        recordFailureAndAdvance(reason);
    }

    private void recordFailureAndAdvance(String reason) {
        if (!running || currentFailed) return;
        currentFailed = true;
        currentFailureReason = reason;
        pageGeneration++;
        SourceItem source = captureQueue.get(captureIndex);
        FailureItem failure = new FailureItem(source.sourceId, source.sequenceNumber, source.label, source.url, reason, System.currentTimeMillis(), false);
        boolean updated = false;
        for (int i = 0; i < failedQueue.size(); i++) {
            FailureItem old = failedQueue.get(i);
            if ((!failure.sourceId.isEmpty() && failure.sourceId.equals(old.sourceId)) || normalizeUrl(old.url).equals(normalizeUrl(failure.url))) {
                failedQueue.set(i, failure);
                updated = true;
                break;
            }
        }
        if (!updated) failedQueue.add(failure);
        saveFailures();
        saveCaptureSession(captureIndex + 1);
        captureStatus.setText(progressPrefix() + " 失败：" + reason);
        handler.postDelayed(() -> {
            if (!running) return;
            destroyWebView();
            loadNext();
        }, 650);
    }

    private void clearFailureForSource(SourceItem source) {
        boolean removed = false;
        for (int i = failedQueue.size() - 1; i >= 0; i--) {
            FailureItem failure = failedQueue.get(i);
            if ((!source.sourceId.isEmpty() && source.sourceId.equals(failure.sourceId)) || normalizeUrl(source.url).equals(normalizeUrl(failure.url))) {
                failedQueue.remove(i);
                removed = true;
            }
        }
        if (removed) saveFailures();
    }

    private void finishQueue() {
        running = false;
        clearCaptureSession();
        captureProgress.setProgress(captureQueue.size());
        captureStatus.setText("采集完成，待处理失败 " + failedQueue.size() + " 条");
        destroyWebView();
        handler.postDelayed(() -> {
            captureScreen.setVisibility(View.GONE);
            sourceScreen.setVisibility(View.VISIBLE);
            refreshSourceList();
            AlertDialog.Builder dialog = new AlertDialog.Builder(this)
                    .setTitle("采集完成")
                    .setMessage("本次处理 " + captureQueue.size() + " 个网址；当前共有 " + failedQueue.size() + " 个待处理失败网址。\n图片已保存到：Pictures/" + ALBUM_ROOT + "/" + today())
                    .setPositiveButton("打开今日图片", (d, w) -> openTodayFirst())
                    .setNegativeButton("关闭", null);
            if (!failedQueue.isEmpty()) {
                dialog.setNeutralButton("查看失败网址", (d, w) -> showFailures());
            }
            dialog.show();
        }, 250);
    }

    private void showFailures() {
        if (failedQueue.isEmpty()) {
            toast("目前没有失败网址");
            return;
        }
        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(14), dp(6), dp(14), dp(10));
        ArrayList<FailureItem> ordered = orderedFailures();
        for (FailureItem item : ordered) {
            int sequence = resolveFailureSequence(item);
            TextView title = new TextView(this);
            title.setText("总清单第" + sequence + "条 · " + item.label);
            title.setTextSize(16);
            title.setTextColor(Color.BLACK);
            title.setTypeface(null, android.graphics.Typeface.BOLD);
            title.setPadding(0, dp(8), 0, dp(2));
            content.addView(title, matchWrap());

            TextView reason = new TextView(this);
            reason.setText(item.reason);
            reason.setTextSize(13);
            reason.setTextColor(item.pendingVerification ? Color.rgb(40, 100, 165) : Color.rgb(190, 45, 45));
            content.addView(reason, matchWrap());

            TextView url = new TextView(this);
            url.setText(item.url);
            url.setTextSize(12);
            url.setTextColor(Color.rgb(25, 90, 180));
            url.setPaintFlags(url.getPaintFlags() | Paint.UNDERLINE_TEXT_FLAG);
            url.setPadding(0, dp(3), 0, dp(4));
            url.setOnClickListener(v -> openExternalUrl(item.url));
            content.addView(url, matchWrap());

            LinearLayout actions = buttonRow();
            actions.addView(button("浏览器打开", v -> openExternalUrl(item.url)), weightedButton());
            Button edit = button("修改此网址", v -> editFailedSource(item, title, reason, url));
            edit.setEnabled(findSourcePosition(item) >= 0);
            actions.addView(edit, weightedButton());
            content.addView(actions, matchWrap());

            View line = new View(this);
            line.setBackgroundColor(Color.LTGRAY);
            content.addView(line, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(1)));
        }
        ScrollView scroll = new ScrollView(this);
        scroll.addView(content, new ScrollView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        new AlertDialog.Builder(this)
                .setTitle("失败网址（" + failedQueue.size() + "）")
                .setView(scroll)
                .setPositiveButton("复制全部", (d, w) -> copyFailures())
                .setNeutralButton("清空", (d, w) -> confirmClearFailures())
                .setNegativeButton("关闭", null)
                .show();
    }

    private void openExternalUrl(String url) {
        try {
            Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
            startActivity(intent);
        } catch (Exception error) {
            toast("没有找到可打开网址的浏览器");
        }
    }

    private void copyFailures() {
        StringBuilder text = new StringBuilder();
        for (FailureItem item : orderedFailures()) {
            if (text.length() > 0) text.append("\n\n");
            text.append("总清单第").append(resolveFailureSequence(item)).append("条 · ").append(item.label)
                    .append('\n').append(item.reason).append('\n').append(item.url);
        }
        ClipboardManager clipboard = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
        clipboard.setPrimaryClip(ClipData.newPlainText("失败网址", text.toString()));
        toast("失败网址已复制");
    }

    private ArrayList<FailureItem> orderedFailures() {
        ArrayList<FailureItem> ordered = new ArrayList<>(failedQueue);
        ordered.sort((first, second) -> Integer.compare(resolveFailureSequence(first), resolveFailureSequence(second)));
        return ordered;
    }

    private int findSourcePosition(FailureItem failure) {
        for (int i = 0; i < sources.size(); i++) {
            SourceItem source = sources.get(i);
            if ((!failure.sourceId.isEmpty() && failure.sourceId.equals(source.sourceId))
                    || normalizeUrl(failure.url).equals(normalizeUrl(source.url))) {
                return i;
            }
        }
        return -1;
    }

    private int resolveFailureSequence(FailureItem failure) {
        int position = findSourcePosition(failure);
        return position >= 0 ? position + 1 : Math.max(1, failure.sequenceNumber);
    }

    private void editFailedSource(FailureItem failure, TextView titleView, TextView reasonView, TextView urlView) {
        int position = findSourcePosition(failure);
        if (position < 0) {
            toast("这条网址已不在总清单中");
            return;
        }
        SourceItem source = sources.get(position);
        EditText input = new EditText(this);
        input.setText(source.manualLabel ? source.label + "|" + source.url : source.url);
        input.setSelection(input.length());
        input.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE | InputType.TYPE_TEXT_VARIATION_URI);
        new AlertDialog.Builder(this)
                .setTitle("修改总清单第" + (position + 1) + "条")
                .setMessage("只改网址可直接粘贴新网址；需要固定名称时填写：名称|网址")
                .setView(input)
                .setPositiveButton("保存", (d, w) -> {
                    String line = input.getText().toString().trim();
                    int split = line.indexOf('|');
                    String newLabel = split > 0 ? line.substring(0, split).trim() : "";
                    String newUrl = split > 0 ? line.substring(split + 1).trim() : line;
                    if (!newUrl.matches("(?i)^https?://.+")) {
                        toast("网址格式不正确");
                        return;
                    }
                    for (int i = 0; i < sources.size(); i++) {
                        if (i != position && normalizeUrl(sources.get(i).url).equals(normalizeUrl(newUrl))) {
                            toast("这个网址已经在总清单中");
                            return;
                        }
                    }
                    source.manualLabel = !newLabel.isEmpty();
                    source.label = source.manualLabel ? newLabel : defaultLabel(newUrl);
                    source.nameResolved = source.manualLabel;
                    source.url = newUrl;
                    failure.sourceId = source.sourceId;
                    failure.sequenceNumber = position + 1;
                    failure.label = source.label;
                    failure.url = source.url;
                    failure.reason = "已修改，等待验证";
                    failure.pendingVerification = true;
                    failure.time = System.currentTimeMillis();
                    saveSources();
                    saveFailures();
                    refreshSourceList();
                    titleView.setText("总清单第" + (position + 1) + "条 · " + failure.label);
                    reasonView.setText(failure.reason);
                    reasonView.setTextColor(Color.rgb(40, 100, 165));
                    urlView.setText(failure.url);
                    toast("已修改，下次采集成功后会自动移除失败记录");
                })
                .setNegativeButton("取消", null)
                .show();
    }

    private void markFailurePendingForSource(SourceItem source, int position, String previousUrl) {
        for (FailureItem failure : failedQueue) {
            if ((!source.sourceId.isEmpty() && source.sourceId.equals(failure.sourceId))
                    || normalizeUrl(previousUrl).equals(normalizeUrl(failure.url))) {
                failure.sourceId = source.sourceId;
                failure.sequenceNumber = position + 1;
                failure.label = source.label;
                failure.url = source.url;
                failure.reason = "已修改，等待验证";
                failure.pendingVerification = true;
                failure.time = System.currentTimeMillis();
                saveFailures();
                return;
            }
        }
    }

    private void removeFailureForSource(SourceItem source) {
        boolean removed = false;
        for (int i = failedQueue.size() - 1; i >= 0; i--) {
            FailureItem failure = failedQueue.get(i);
            if ((!source.sourceId.isEmpty() && source.sourceId.equals(failure.sourceId))
                    || normalizeUrl(source.url).equals(normalizeUrl(failure.url))) {
                failedQueue.remove(i);
                removed = true;
            }
        }
        if (removed) saveFailures();
    }

    private void confirmClearFailures() {
        new AlertDialog.Builder(this)
                .setTitle("清空失败网址")
                .setMessage("确定清空当前保存的失败网址吗？")
                .setPositiveButton("清空", (d, w) -> {
                    failedQueue.clear();
                    saveFailures();
                    refreshSourceList();
                })
                .setNegativeButton("取消", null)
                .show();
    }

    private void confirmStop() {
        new AlertDialog.Builder(this)
                .setTitle("停止采集")
                .setMessage("确定暂停当前批量任务吗？已经保存的图片和当前断点都会保留，稍后可点击“继续上次”。")
                .setPositiveButton("停止", (d, w) -> {
                    saveCaptureSession(checkpointNextIndex);
                    running = false;
                    pageGeneration++;
                    handler.removeCallbacksAndMessages(null);
                    destroyWebView();
                    captureScreen.setVisibility(View.GONE);
                    sourceScreen.setVisibility(View.VISIBLE);
                    refreshSourceList();
                })
                .setNegativeButton("继续采集", null)
                .show();
    }

    private void openTodayFirst() {
        Uri uri = findFirstTodayImage();
        if (uri == null) {
            toast("今天还没有保存图片");
            return;
        }
        Intent intent = new Intent(Intent.ACTION_VIEW);
        intent.setDataAndType(uri, "image/*");
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        try {
            startActivity(intent);
        } catch (Exception error) {
            toast("没有找到可打开图片的相册应用");
        }
    }

    private Uri findFirstTodayImage() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) {
            File directory = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES), ALBUM_ROOT + "/" + today());
            String[] projection = {MediaStore.Images.Media._ID};
            try (Cursor cursor = getContentResolver().query(
                    MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                    projection,
                    MediaStore.Images.Media.DATA + " LIKE ?",
                    new String[]{directory.getAbsolutePath() + "/%"},
                    MediaStore.Images.Media.DISPLAY_NAME + " ASC")) {
                if (cursor != null && cursor.moveToFirst()) {
                    long id = cursor.getLong(0);
                    return ContentUris.withAppendedId(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, id);
                }
            }
            return null;
        }
        String relative = Environment.DIRECTORY_PICTURES + "/" + ALBUM_ROOT + "/" + today() + "/";
        String[] projection = {MediaStore.Images.Media._ID};
        try (Cursor cursor = getContentResolver().query(
                MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                projection,
                MediaStore.Images.Media.RELATIVE_PATH + "=?",
                new String[]{relative},
                MediaStore.Images.Media.DISPLAY_NAME + " ASC")) {
            if (cursor != null && cursor.moveToFirst()) {
                long id = cursor.getLong(0);
                return ContentUris.withAppendedId(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, id);
            }
        }
        return null;
    }

    private void confirmDeleteToday() {
        new AlertDialog.Builder(this)
                .setTitle("删除今日截图")
                .setMessage("将删除“" + today() + "”文件夹中的全部采集截图。删除后通常无法恢复，确定继续吗？")
                .setPositiveButton("全部删除", (d, w) -> deleteToday())
                .setNegativeButton("取消", null)
                .show();
    }

    private void deleteToday() {
        int deleted = 0;
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                String relative = Environment.DIRECTORY_PICTURES + "/" + ALBUM_ROOT + "/" + today() + "/";
                deleted = getContentResolver().delete(
                        MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                        MediaStore.Images.Media.RELATIVE_PATH + "=?",
                        new String[]{relative});
            } else {
                File directory = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES), ALBUM_ROOT + "/" + today());
                File[] files = directory.listFiles();
                if (files != null) {
                    for (File file : files) if (file.delete()) deleted++;
                }
                if (directory.exists()) directory.delete();
            }
            toast("已删除 " + deleted + " 张今日截图");
        } catch (Exception error) {
            toast("删除失败：" + error.getMessage());
        }
    }

    private void refreshSourceList() {
        int enabled = 0;
        int normal = 0;
        int vpn = 0;
        for (SourceItem item : sources) {
            if (item.enabled) enabled++;
            if (GROUP_VPN.equals(item.group)) vpn++;
            else normal++;
        }
        countText.setText("共 " + sources.size() + " 个网址（普通" + normal + "，VPN" + vpn
                + "），已启用 " + enabled + " 个；最近失败 " + failedQueue.size() + " 个");
        failureButton.setText(failedQueue.isEmpty() ? "失败网址" : "失败(" + failedQueue.size() + ")");
        if (resumeButton != null) {
            ResumeSession session = loadCaptureSession();
            if (session != null && session.nextIndex < session.items.size()) {
                SourceItem next = session.items.get(session.nextIndex);
                int shown = next.sequenceNumber > 0 ? next.sequenceNumber : session.nextIndex + 1;
                resumeButton.setText("继续上次（第" + shown + "条）");
                resumeButton.setEnabled(true);
            } else {
                resumeButton.setText("暂无未完成任务");
                resumeButton.setEnabled(false);
            }
        }
        adapter.notifyDataSetChanged();
    }

    private void loadSources() {
        android.content.SharedPreferences preferences = getSharedPreferences(PREFS, MODE_PRIVATE);
        if (!preferences.contains(KEY_SOURCES)) {
            saveSources();
            return;
        }
        String json = preferences.getString(KEY_SOURCES, "[]");
        try {
            JSONArray array = new JSONArray(json);
            for (int i = 0; i < array.length(); i++) {
                JSONObject object = array.getJSONObject(i);
                String url = object.optString("url", "");
                String label = object.optString("label", defaultLabel(url));
                boolean manualLabel = object.has("manualLabel")
                        ? object.optBoolean("manualLabel", false)
                        : !label.equalsIgnoreCase(defaultLabel(url));
                boolean nameResolved = object.has("nameResolved")
                        ? object.optBoolean("nameResolved", manualLabel)
                        : manualLabel;
                SourceItem item = new SourceItem(
                        label,
                        url,
                        object.optBoolean("enabled", true),
                        manualLabel,
                        normalizeMode(object.optString("captureMode", MODE_SMART)),
                        nameResolved,
                        object.optBoolean("loadImages", false));
                item.sourceId = object.optString("sourceId", item.sourceId);
                item.group = normalizeGroup(object.optString("group", GROUP_NORMAL));
                sources.add(item);
            }
        } catch (JSONException ignored) {
            sources.clear();
        }
    }

    private void saveSources() {
        JSONArray array = new JSONArray();
        for (SourceItem item : sources) {
            JSONObject object = new JSONObject();
            try {
                object.put("sourceId", item.sourceId);
                object.put("label", item.label);
                object.put("url", item.url);
                object.put("enabled", item.enabled);
                object.put("manualLabel", item.manualLabel);
                object.put("captureMode", item.captureMode);
                object.put("nameResolved", item.nameResolved);
                object.put("loadImages", item.loadImages);
                object.put("group", item.group);
                array.put(object);
            } catch (JSONException ignored) {
            }
        }
        getSharedPreferences(PREFS, MODE_PRIVATE).edit().putString(KEY_SOURCES, array.toString()).apply();
    }

    private void loadFailures() {
        String json = getSharedPreferences(PREFS, MODE_PRIVATE).getString(KEY_FAILURES, "[]");
        try {
            JSONArray array = new JSONArray(json);
            for (int i = 0; i < array.length(); i++) {
                JSONObject object = array.getJSONObject(i);
                String url = object.optString("url", "");
                if (url.isEmpty()) continue;
                failedQueue.add(new FailureItem(
                        object.optString("sourceId", ""),
                        object.optInt("sequenceNumber", i + 1),
                        object.optString("label", defaultLabel(url)),
                        url,
                        object.optString("reason", "打开失败"),
                        object.optLong("time", 0L),
                        object.optBoolean("pendingVerification", false)));
            }
        } catch (JSONException ignored) {
            failedQueue.clear();
        }
    }

    private void saveFailures() {
        JSONArray array = new JSONArray();
        for (FailureItem item : failedQueue) {
            JSONObject object = new JSONObject();
            try {
                object.put("sourceId", item.sourceId);
                object.put("sequenceNumber", item.sequenceNumber);
                object.put("label", item.label);
                object.put("url", item.url);
                object.put("reason", item.reason);
                object.put("time", item.time);
                object.put("pendingVerification", item.pendingVerification);
                array.put(object);
            } catch (JSONException ignored) {
            }
        }
        getSharedPreferences(PREFS, MODE_PRIVATE).edit().putString(KEY_FAILURES, array.toString()).apply();
    }

    private String defaultLabel(String url) {
        try {
            String host = new URI(url).getHost();
            return host == null || host.isEmpty() ? "未命名来源" : host;
        } catch (Exception ignored) {
            return "未命名来源";
        }
    }

    private String normalizeUrl(String value) {
        String url = value.trim();
        while (url.endsWith("/")) url = url.substring(0, url.length() - 1);
        return url.toLowerCase(Locale.ROOT);
    }

    private String safeName(String value) {
        String clean = value.replaceAll("[\\\\/:*?\"<>|\\s]+", "_");
        if (clean.length() > 36) clean = clean.substring(0, 36);
        return clean.isEmpty() ? "未命名来源" : clean;
    }

    private String today() {
        return new SimpleDateFormat("yyyy-MM-dd", Locale.CHINA).format(new Date());
    }

    private Button button(String text, View.OnClickListener listener) {
        Button button = new Button(this);
        button.setText(text);
        button.setTextSize(13);
        button.setAllCaps(false);
        button.setOnClickListener(listener);
        button.setPadding(dp(2), 0, dp(2), 0);
        return button;
    }

    private LinearLayout buttonRow() {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        return row;
    }

    private LinearLayout.LayoutParams weightedButton() {
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(0, dp(43), 1);
        params.setMargins(dp(2), dp(2), dp(2), dp(2));
        return params;
    }

    private LinearLayout.LayoutParams matchWrap() {
        return new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
    }

    private FrameLayout.LayoutParams frameMatch() {
        return new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    private void toast(String text) {
        Toast.makeText(this, text, Toast.LENGTH_SHORT).show();
    }

    private void chooseCaptureMode(int position) {
        SourceItem item = sources.get(position);
        String[] values = {MODE_SMART, MODE_FIXED_SHORT, MODE_FAST_LONG, MODE_COMPAT_SHORT, MODE_COMPAT_LONG};
        String[] labels = {
                "智能截图（按期号定位，推荐）",
                "固定短图（从顶部截4800像素）",
                "固定长图（从顶部截8000像素）",
                "兼容短图（展开内部内容后从顶部截4800像素）",
                "兼容长图（展开内部内容后从顶部截8000像素）"
        };
        int checked = 0;
        for (int i = 0; i < values.length; i++) {
            if (values[i].equals(item.captureMode)) checked = i;
        }
        new AlertDialog.Builder(this)
                .setTitle(item.label + "：截图模式")
                .setSingleChoiceItems(labels, checked, (dialog, which) -> {
                    item.captureMode = values[which];
                    saveSources();
                    refreshSourceList();
                    dialog.dismiss();
                })
                .setNegativeButton("取消", null)
                .show();
    }

    private void toggleImageMode(int position) {
        SourceItem item = sources.get(position);
        item.loadImages = !item.loadImages;
        saveSources();
        refreshSourceList();
        toast(item.label + "：已切换为" + imageModeLabel(item.loadImages));
    }

    private static class SourceItem {
        String sourceId;
        String label;
        String url;
        boolean enabled;
        boolean manualLabel;
        String captureMode;
        boolean nameResolved;
        boolean loadImages;
        String group;
        int sequenceNumber;
        int sequenceTotal;
        boolean captureRegionFound;
        float captureRegionLeft;
        float captureRegionTop;
        float captureRegionWidth;
        float captureRegionHeight;
        float captureDocumentWidth;
        float captureDocumentHeight;
        boolean latestIssueFound;
        boolean latestIssueAtBottom;
        int latestIssueNumber;
        float latestIssueTop;
        float latestIssueHeight;

        SourceItem(String label, String url, boolean enabled, boolean manualLabel, String captureMode, boolean nameResolved, boolean loadImages) {
            this.sourceId = UUID.randomUUID().toString();
            this.label = label;
            this.url = url;
            this.enabled = enabled;
            this.manualLabel = manualLabel;
            this.captureMode = captureMode;
            this.nameResolved = nameResolved;
            this.loadImages = loadImages;
            this.group = GROUP_NORMAL;
        }

        SourceItem copy() {
            SourceItem copy = new SourceItem(label, url, enabled, manualLabel, captureMode, nameResolved, loadImages);
            copy.sourceId = sourceId;
            copy.group = group;
            copy.sequenceNumber = sequenceNumber;
            copy.sequenceTotal = sequenceTotal;
            return copy;
        }

        void resetCaptureHints() {
            captureRegionFound = false;
            captureRegionLeft = 0f;
            captureRegionTop = 0f;
            captureRegionWidth = 0f;
            captureRegionHeight = 0f;
            captureDocumentWidth = 0f;
            captureDocumentHeight = 0f;
            latestIssueFound = false;
            latestIssueAtBottom = false;
            latestIssueNumber = 0;
            latestIssueTop = 0f;
            latestIssueHeight = 0f;
        }
    }

    private static class ResumeSession {
        ArrayList<SourceItem> items;
        int nextIndex;
        long savedAt;

        ResumeSession(ArrayList<SourceItem> items, int nextIndex, long savedAt) {
            this.items = items;
            this.nextIndex = nextIndex;
            this.savedAt = savedAt;
        }
    }

    private static class FailureItem {
        String sourceId;
        int sequenceNumber;
        String label;
        String url;
        String reason;
        long time;
        boolean pendingVerification;

        FailureItem(String sourceId, int sequenceNumber, String label, String url, String reason, long time, boolean pendingVerification) {
            this.sourceId = sourceId == null ? "" : sourceId;
            this.sequenceNumber = sequenceNumber;
            this.label = label;
            this.url = url;
            this.reason = reason;
            this.time = time;
            this.pendingVerification = pendingVerification;
        }
    }

    private class SourceAdapter extends BaseAdapter {
        @Override
        public int getCount() {
            return sources.size();
        }

        @Override
        public Object getItem(int position) {
            return sources.get(position);
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            SourceItem item = sources.get(position);
            LinearLayout row = new LinearLayout(MainActivity.this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setGravity(Gravity.CENTER_VERTICAL);
            row.setPadding(dp(2), dp(4), dp(2), dp(4));

            CheckBox enabled = new CheckBox(MainActivity.this);
            enabled.setChecked(item.enabled);
            enabled.setOnCheckedChangeListener((buttonView, isChecked) -> {
                item.enabled = isChecked;
                saveSources();
                refreshSourceList();
            });
            row.addView(enabled, new LinearLayout.LayoutParams(dp(45), dp(48)));

            LinearLayout textBox = new LinearLayout(MainActivity.this);
            textBox.setOrientation(LinearLayout.VERTICAL);
            TextView label = new TextView(MainActivity.this);
            label.setText((position + 1) + ". " + (GROUP_VPN.equals(item.group) ? "[VPN] " : "") + item.label);
            label.setTextSize(15);
            label.setTextColor(Color.BLACK);
            TextView url = new TextView(MainActivity.this);
            url.setText(item.url);
            url.setTextSize(11);
            url.setTextColor(Color.GRAY);
            url.setMaxLines(2);
            textBox.addView(label, matchWrap());
            textBox.addView(url, matchWrap());
            row.addView(textBox, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));

            Button mode = button(modeLabel(item.captureMode), v -> chooseCaptureMode(position));
            row.addView(mode, new LinearLayout.LayoutParams(dp(58), dp(43)));
            Button images = button(imageModeLabel(item.loadImages), v -> toggleImageMode(position));
            images.setTextColor(item.loadImages ? Color.rgb(20, 105, 175) : Color.DKGRAY);
            row.addView(images, new LinearLayout.LayoutParams(dp(54), dp(43)));
            Button edit = button("改", v -> editSource(position));
            row.addView(edit, new LinearLayout.LayoutParams(dp(44), dp(43)));
            Button delete = button("删", v -> confirmDeleteSource(position));
            row.addView(delete, new LinearLayout.LayoutParams(dp(44), dp(43)));
            return row;
        }
    }
}
